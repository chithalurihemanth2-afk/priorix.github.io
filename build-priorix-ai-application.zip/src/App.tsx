import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

/* ═══════════════════════════════════════════════════════════════
   TYPES
   ═══════════════════════════════════════════════════════════════ */

type UserRole = "user" | "admin";

interface AppUser {
  id: string;
  name: string;
  email: string;
  password: string;
  role: UserRole;
  createdAt: string;
}

interface Ticket {
  id: string;
  subject: string;
  description: string;
  attachments: string;
  status: "open" | "spam" | "in_progress" | "resolved";
  priority: "critical" | "high" | "medium" | "low";
  department: string;
  deadline: string;
  aiSuggestion: string;
  isSpam: boolean;
  userEmail: string;
  createdAt: string;
  /* Enterprise classification fields */
  category: string;
  subCategory: string;
  impact: "high" | "medium" | "low";
  urgency: "high" | "medium" | "low";
  impactScore: number;
  urgencyScore: number;
  confidenceScore: number;
  sentiment: string;
  slaResponseTime: string;
  slaResolutionTime: string;
  clarificationQuestions: string[];
  /* v3.0 Ultra-Advanced fields */
  secondaryDepartment: string;
  priorityModifiers: string[];
  validationPassed: boolean;
  financialIssue: boolean;
  priorityScore: number;
  decisionPipeline: string[];
}

interface Feedback {
  id: string;
  ticketId: string;
  rating: number;
  comment: string;
  createdAt: string;
}

interface Session {
  userId: string;
  name: string;
  email: string;
  role: UserRole;
}

type Page =
  | "landing"
  | "login"
  | "signup"
  | "user-dashboard"
  | "admin-dashboard";

/* ═══════════════════════════════════════════════════════════════
   CONSTANTS
   ═══════════════════════════════════════════════════════════════ */

const ADMIN_EMAIL = "chithalurihemanth972@gmail.com";
const ADMIN_PASSWORD = "Hemu@2007";
const OPENAI_KEY: string = import.meta.env.VITE_OPENAI_API_KEY || "";
const WEBHOOK_URL: string = import.meta.env.VITE_N8N_WEBHOOK_URL || "";

/* ── EmailJS (browser-based email — no server needed) ── */
const EJS_SERVICE_ID: string = import.meta.env.VITE_EMAILJS_SERVICE_ID || "";
const EJS_TEMPLATE_ID: string = import.meta.env.VITE_EMAILJS_TEMPLATE_ID || "";
const EJS_PUBLIC_KEY: string = import.meta.env.VITE_EMAILJS_PUBLIC_KEY || "";
const EMAIL_READY = !!(EJS_SERVICE_ID && EJS_TEMPLATE_ID && EJS_PUBLIC_KEY);

const LS_USERS = "priorix_users";
const LS_TICKETS = "priorix_tickets";
const LS_FEEDBACK = "priorix_feedback";
const LS_SESSION = "priorix_session";

const genId = () =>
  Math.random().toString(36).slice(2, 11) +
  Date.now().toString(36).slice(-4);

/* ═══════════════════════════════════════════════════════════════
   LOCAL-STORAGE HELPERS
   ═══════════════════════════════════════════════════════════════ */

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}
function save(key: string, data: unknown) {
  localStorage.setItem(key, JSON.stringify(data));
}

/* ═══════════════════════════════════════════════════════════════
   EMAIL SERVICE  (EmailJS — sends real emails from the browser)
   ───────────────────────────────────────────────────────────────
   Setup (one-time, 5 minutes):
     1. Create free account at  https://www.emailjs.com
     2. Add Gmail service  → connect chithalurihemanth972@gmail.com
     3. Create ONE template:
          To:      {{to_email}}
          Subject: {{subject}}
          Body:    {{{message}}}
     4. Copy Service ID, Template ID, Public Key into .env:
          VITE_EMAILJS_SERVICE_ID=service_xxx
          VITE_EMAILJS_TEMPLATE_ID=template_xxx
          VITE_EMAILJS_PUBLIC_KEY=xxx
   ═══════════════════════════════════════════════════════════════ */

interface EmailStatus {
  sending: boolean;
  lastType: string | null;
  lastResult: "success" | "failed" | "not_configured" | null;
  lastMessage: string;
}

const LS_EMAIL_LOG = "priorix_email_log";
interface EmailLogEntry {
  id: string; type: string; to: string; subject: string;
  status: "sent" | "logged" | "failed"; timestamp: string;
}
function getEmailLog(): EmailLogEntry[] { return load<EmailLogEntry[]>(LS_EMAIL_LOG, []); }

async function emailjsSend(toEmail: string, subject: string, htmlBody: string): Promise<boolean> {
  try {
    const res = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        service_id: EJS_SERVICE_ID,
        template_id: EJS_TEMPLATE_ID,
        user_id: EJS_PUBLIC_KEY,
        template_params: { to_email: toEmail, subject, message: htmlBody },
      }),
    });
    return res.ok;
  } catch { return false; }
}

/* ── HTML email templates ────────────────────────────────────── */

function htmlTicketCreated(ticket: Ticket, userName: string): string {
  const dl = new Date(ticket.deadline).toLocaleDateString("en-US",{month:"long",day:"numeric",year:"numeric"});
  const pc = ticket.priority==="high"?"#ef4444":ticket.priority==="medium"?"#f59e0b":"#22c55e";
  return `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#f8fafc;border-radius:12px;overflow:hidden">
<div style="background:linear-gradient(135deg,#0ea5e9,#8b5cf6);padding:28px;text-align:center"><h1 style="color:#fff;margin:0;font-size:22px">🎫 Ticket Confirmed</h1></div>
<div style="padding:24px"><p style="font-size:16px;color:#334155">Hi ${userName},</p>
<p style="color:#475569">Your support ticket has been created. Here are the details:</p>
<div style="background:#fff;border-radius:8px;padding:16px;margin:16px 0;border:1px solid #e2e8f0">
<p style="margin:6px 0"><strong>Ticket ID:</strong> <code style="background:#f1f5f9;padding:2px 8px;border-radius:4px">${ticket.id}</code></p>
<p style="margin:6px 0"><strong>Subject:</strong> ${ticket.subject}</p>
<p style="margin:6px 0"><strong>Priority:</strong> <span style="color:${pc};font-weight:700">${ticket.priority.toUpperCase()}</span></p>
<p style="margin:6px 0"><strong>Department:</strong> ${ticket.department}</p>
<p style="margin:6px 0"><strong>Deadline:</strong> ${dl}</p>
</div><p style="color:#64748b;font-size:14px">We will notify you when the status changes. Thank you for reaching out!</p></div>
<div style="background:#f1f5f9;padding:14px;text-align:center;color:#94a3b8;font-size:12px">PRiorix Support System &bull; Automated Message</div></div>`;
}

function htmlTicketUpdated(ticket: Ticket, userName: string, oldS: string, newS: string): string {
  const colors: Record<string,string> = {open:"#3b82f6",in_progress:"#f59e0b",resolved:"#22c55e",spam:"#ef4444"};
  return `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#f8fafc;border-radius:12px;overflow:hidden">
<div style="background:linear-gradient(135deg,#0ea5e9,#8b5cf6);padding:28px;text-align:center"><h1 style="color:#fff;margin:0;font-size:22px">🔄 Ticket Status Updated</h1></div>
<div style="padding:24px"><p style="font-size:16px;color:#334155">Hi ${userName},</p>
<p style="color:#475569">Your ticket status has been updated:</p>
<div style="background:#fff;border-radius:8px;padding:16px;margin:16px 0;border:1px solid #e2e8f0">
<p style="margin:6px 0"><strong>Ticket ID:</strong> <code style="background:#f1f5f9;padding:2px 8px;border-radius:4px">${ticket.id}</code></p>
<p style="margin:6px 0"><strong>Subject:</strong> ${ticket.subject}</p>
<p style="margin:6px 0"><strong>Status:</strong> <span style="color:#94a3b8;text-decoration:line-through">${oldS.replace("_"," ")}</span> → <span style="color:${colors[newS]||"#0ea5e9"};font-weight:700">${newS.replace("_"," ")}</span></p>
</div><p style="color:#64748b;font-size:14px">Log in to PRiorix to view more details.</p></div>
<div style="background:#f1f5f9;padding:14px;text-align:center;color:#94a3b8;font-size:12px">PRiorix Support System &bull; Automated Message</div></div>`;
}

function htmlAdminAlert(ticket: Ticket): string {
  const dl = ticket.deadline?new Date(ticket.deadline).toLocaleDateString("en-US",{month:"long",day:"numeric",year:"numeric"}):"N/A";
  return `<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#f8fafc;border-radius:12px;overflow:hidden">
<div style="background:linear-gradient(135deg,#ef4444,#f97316);padding:28px;text-align:center"><h1 style="color:#fff;margin:0;font-size:22px">🚨 HIGH PRIORITY TICKET</h1><p style="color:#fef2f2;margin:4px 0 0">Requires immediate attention</p></div>
<div style="padding:24px"><p style="color:#475569">A high-priority ticket has been created:</p>
<div style="background:#fff;border-radius:8px;padding:16px;margin:16px 0;border:2px solid #fecaca">
<p style="margin:6px 0"><strong>Ticket ID:</strong> <code style="background:#fef2f2;padding:2px 8px;border-radius:4px">${ticket.id}</code></p>
<p style="margin:6px 0"><strong>Subject:</strong> ${ticket.subject}</p>
<p style="margin:6px 0"><strong>From:</strong> ${ticket.userEmail}</p>
<p style="margin:6px 0"><strong>Priority:</strong> <span style="color:#ef4444;font-weight:700">HIGH</span></p>
<p style="margin:6px 0"><strong>Department:</strong> ${ticket.department}</p>
<p style="margin:6px 0"><strong>Deadline:</strong> ${dl}</p>
<p style="margin:6px 0"><strong>AI Suggestion:</strong> ${ticket.aiSuggestion||"N/A"}</p>
</div><p style="color:#dc2626;font-size:14px;font-weight:600">⚡ Please review this ticket immediately in the admin dashboard.</p></div>
<div style="background:#f1f5f9;padding:14px;text-align:center;color:#94a3b8;font-size:12px">PRiorix Support System &bull; Automated Alert</div></div>`;
}

/* ── Hook ────────────────────────────────────────────────────── */

function useEmailService() {
  const [emailStatus, setEmailStatus] = useState<EmailStatus>({
    sending: false, lastType: null, lastResult: null, lastMessage: "",
  });

  async function doSend(type: string, to: string, subject: string, html: string) {
    setEmailStatus(s => ({ ...s, sending: true, lastType: type, lastResult: null, lastMessage: "Sending email…" }));

    let ok = false;
    if (EMAIL_READY) {
      ok = await emailjsSend(to, subject, html);
    }

    /* log to localStorage regardless */
    const log = getEmailLog();
    log.unshift({ id: genId(), type, to, subject, status: ok?"sent":EMAIL_READY?"failed":"logged", timestamp: new Date().toISOString() });
    if (log.length > 200) log.length = 200;
    save(LS_EMAIL_LOG, log);

    const result: EmailStatus["lastResult"] = ok ? "success" : EMAIL_READY ? "failed" : "not_configured";
    const msg = ok
      ? `✅ Email sent to ${to}`
      : EMAIL_READY
        ? `⚠️ Email delivery failed — logged internally`
        : `📧 Email logged (configure EmailJS for real delivery)`;

    setEmailStatus(s => ({ ...s, sending: false, lastResult: result, lastMessage: msg }));
  }

  async function emailTicketCreated(ticket: Ticket, userName: string) {
    await doSend("ticket_created", ticket.userEmail, `[PRiorix] Ticket Created: ${ticket.subject}`, htmlTicketCreated(ticket, userName));
    if (ticket.priority === "high") await emailAdminAlert(ticket);
  }

  async function emailTicketUpdated(ticket: Ticket, userName: string, oldStatus: string, newStatus: string) {
    await doSend("ticket_updated", ticket.userEmail, `[PRiorix] Ticket Updated: ${ticket.subject}`, htmlTicketUpdated(ticket, userName, oldStatus, newStatus));
  }

  async function emailAdminAlert(ticket: Ticket) {
    await doSend("admin_alert", ADMIN_EMAIL, `[PRiorix] 🚨 HIGH PRIORITY: ${ticket.subject}`, htmlAdminAlert(ticket));
  }

  return { emailStatus, emailTicketCreated, emailTicketUpdated, emailAdminAlert, EMAIL_READY };
}

function getUsers(): AppUser[] {
  return load<AppUser[]>(LS_USERS, []);
}
function getTickets(): Ticket[] {
  return load<Ticket[]>(LS_TICKETS, []);
}
function getFeedbacks(): Feedback[] {
  return load<Feedback[]>(LS_FEEDBACK, []);
}
function getSession(): Session | null {
  return load<Session | null>(LS_SESSION, null);
}

function seedAdmin() {
  const users = getUsers();
  if (!users.find((u) => u.email === ADMIN_EMAIL)) {
    users.push({
      id: "admin-root",
      name: "Admin",
      email: ADMIN_EMAIL,
      password: ADMIN_PASSWORD,
      role: "admin",
      createdAt: new Date().toISOString(),
    });
    save(LS_USERS, users);
  }
}

/* ═══════════════════════════════════════════════════════════════
   OPENAI HELPERS
   ═══════════════════════════════════════════════════════════════ */

interface ChatMsg {
  role: "system" | "user" | "assistant";
  content: string;
}

async function callOpenAI(messages: ChatMsg[]): Promise<string> {
  if (!OPENAI_KEY) return mockAI(messages);
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${OPENAI_KEY}`,
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      messages,
      temperature: 0.7,
      max_tokens: 600,
    }),
  });
  if (!res.ok) throw new Error(`OpenAI error ${res.status}`);
  const data = await res.json();
  return data.choices?.[0]?.message?.content?.trim() ?? "";
}

function mockAI(messages: ChatMsg[]): Promise<string> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const userTurns = messages.filter((m) => m.role === "user").length;

      if (userTurns >= 3) {
        resolve(
          "SOLUTION: Based on our detailed analysis, here is my comprehensive recommendation:\n\n1. **Immediate Action**: Clear your browser cache and cookies, then retry the operation.\n2. **System Check**: Restart your device and install any pending system updates.\n3. **Account Verification**: Ensure your credentials are correct and try resetting your password if needed.\n4. **Network Check**: Verify your internet connection stability and disable VPN if active.\n5. **Escalation Path**: If the issue persists after these steps, our engineering team will investigate the backend systems.\n\nI've classified this ticket with the appropriate priority and department. A support agent will follow up within the SLA window."
        );
      } else if (userTurns >= 2) {
        resolve(
          "SOLUTION: Based on the information provided, here is my recommendation:\n\n1. Try clearing your browser cache and cookies, then retry.\n2. If the issue persists, restart your device and check for any pending system updates.\n3. For account-specific problems, ensure your credentials are correct and try resetting your password.\n\nIf none of these steps resolve the issue, our support team will investigate further."
        );
      } else {
        /* Enterprise-grade clarification engine */
        const questions: string[] = [
          "How many users are affected by this issue? (Just you / your team / the entire organization)",
          "Is your work completely blocked, or can you continue with a workaround?",
          "When did this issue first occur?",
          "Is this related to technical systems, HR/payroll, billing, or operations?",
        ];
        const pick = questions.sort(() => 0.5 - Math.random()).slice(0, 2);
        resolve(
          `I'm analyzing your issue using our enterprise classification system. To ensure accurate routing and priority, I need a bit more information:\n\n${pick.map((q, i) => `${i + 1}. ${q}`).join("\n")}\n\nThis helps me assign the right department, priority level, and SLA timeline.`
        );
      }
    }, 1200 + Math.random() * 800);
  });
}

/* ═══════════════════════════════════════════════════════════════
   ULTRA-ADVANCED AI AGENT v3.0 — DECISION ENGINE
   5-Layer Architecture: Signal → Domain → Impact → Priority → Validate
   ═══════════════════════════════════════════════════════════════ */

const ENTERPRISE_SYSTEM_PROMPT = `You are PRiorix — NOT a chatbot, but a DECISION ENGINE. Every output must be justified, validated, and consistent with domain logic.

You operate in 5 layers:
Layer 1: Signal Extraction — explicit keywords, implicit meaning, context signals, sentiment, business signals
Layer 2: Domain Detection — weighted keyword scoring with override rules and conflict resolution
Layer 3: Risk & Business Impact Analysis — financial boost, user count, revenue risk
Layer 4: Priority + SLA Engine — non-linear scoring with modifiers
Layer 5: Validation + Correction Loop — 3-check validation before output

═══ META RULE ═══
You are a DECISION ENGINE, NOT a chatbot.
Every output must be: justified, validated, consistent with domain logic.

═══ LAYER 1: SIGNAL EXTRACTION ENGINE ═══
Extract from every input:
- Explicit keywords (payment, login, error, etc.)
- Implicit meaning ("not working" → failure)
- Context signals ("after update", "since yesterday")
- Sentiment (frustration, urgency, anger)
- Business signals (money, deadline, users affected)

Advanced signal detection example:
"Amount deducted but service not activated"
→ payment (finance) + deducted (critical financial) + service failure + immediate need
→ This is FINANCE + SERVICE FAILURE, NOT IT

═══ LAYER 2: DOMAIN DETECTION (WEIGHTED MODEL) ═══
Score each domain using weighted keywords:

IT/TECHNICAL:
  +6 login, +8 "system error", +10 "server down", +6 bug, +8 crash, +6 API, +6 database, +4 slow, +6 network, +4 install, +6 authentication
  Patterns: "not working", "failed to load", "unable to access", "system down"
  Sub-categories: Authentication, Application crash, Feature not working, Integration/API failure, Device failure, Camera/mic, Internet/VPN, Server unreachable
  Boost: "system down" → Critical, "all users" → Critical, "after update" → High

HR:
  +6 leave, +8 payroll, +8 salary, +6 attendance, +6 benefits, +6 "employee ID"
  Sub-categories: Payroll Issue, Leave Request, Attendance Correction, Employee Data Update

FINANCE:
  +10 "amount deducted", +8 "payment failed", +6 refund, +8 billing, +6 invoice, +6 transaction
  Sub-categories: Payment Failure, Refund Issue, Invoice/Billing Error, Transaction Dispute
  ⚠️ OVERRIDE RULE: IF financial keywords score ≥ 8 → FORCE Finance even if IT keywords exist

OPERATIONS:
  +6 delay, +6 delivery, +6 process, +6 workflow, +6 logistics
  Sub-categories: Service Delay, Process Failure, Workflow Bottleneck, Logistics Issue

CUSTOMER_SUPPORT:
  +6 complaint, +6 unhappy, +6 feedback, +6 "bad experience"
  Sub-categories: Complaint, General Inquiry, Feedback

⚠️ Conflict Resolution:
IF Finance + IT both detected:
  Check root cause: Money issue → Finance primary, IT secondary. Access issue → IT primary, Finance secondary.
IF multiple departments: Choose primary issue, add secondary tag.
Priority hierarchy: Money > System > Process > General

═══ LAYER 3: IMPACT ENGINE ═══
Impact Dimensions (not just users):
1. User Count
2. Business Value
3. Revenue Risk
4. System Criticality

High Impact (3): Entire system down, >10 users, business-critical blocked, revenue loss, compliance risk
Medium Impact (2): 2-10 users, partial functionality loss, work slowed
Low Impact (1): Single user, minor inconvenience, workaround exists

💰 FINANCIAL IMPACT BOOST:
IF money involved → increase impact by +1 level (max 3)
Reason: Financial issues are high sensitivity

═══ LAYER 4: URGENCY ENGINE ═══
Urgency = f(Time Pressure + Work Block + User Expectation)

High Urgency (3): Work completely blocked, deadline within hours, real-time system failure
Medium Urgency (2): Work partially affected, deadline within 24 hours
Low Urgency (1): No immediate deadline, informational/cosmetic

🔥 HIDDEN URGENCY DETECTION:
IF: paid service not working OR real-time system needed OR user says "urgent" → Urgency = High

═══ LAYER 5: PRIORITY ENGINE (NON-LINEAR WITH MODIFIERS) ═══
Base Score = Impact × Urgency

Modifiers:
+2 → financial issue detected
+2 → user frustration/anger
+3 → business keywords (loss, deadline, urgent, revenue)

Final Mapping:
Score ≥ 9 → Critical
Score 6-8 → High
Score 3-5 → Medium
Score ≤ 2 → Low

═══ SLA INTELLIGENCE (DYNAMIC) ═══
SLA adapts to context:
Critical: Response 15min, Resolution 2-4hrs
High: Response 30min, Resolution 6-8hrs
Medium: Response 1hr, Resolution 24hrs
Low: Response 4hrs, Resolution 48-72hrs

IF financial + urgent → compress SLA (faster than normal)
Example: Payment issue urgent → Response 15min, Resolution 4-6hrs

═══ RESPONSE GENERATION ENGINE ═══
IF Finance: Ask transaction details, assure resolution, explain next steps, add reassurance
IF IT: Troubleshoot with specific steps
IF HR: Collect employee info, check policy
IF Ops: Check process timeline, identify bottleneck

Response Personalization:
IF user paid money → add reassurance tone: "We understand the importance of this issue..."
IF user frustrated → empathize first, then solve

═══ VALIDATION LOOP (3 CHECKS BEFORE OUTPUT) ═══
CHECK 1: IF "payment" detected AND department ≠ Finance → FIX department to Finance
CHECK 2: IF financial issue AND solution = generic troubleshooting → REPLACE with financial-specific response
CHECK 3: IF urgency low but service completely blocked → INCREASE urgency

═══ SENTIMENT + BEHAVIORAL LOGIC ═══
Angry tone → increase urgency +1 (max 3)
Repeated issue → increase impact +1 (max 3)
Polite tone → no change
Detect: angry, frustrated, neutral, satisfied, anxious

═══ CONFIDENCE ENGINE ═══
Confidence = f(keyword clarity + domain certainty + impact clarity + urgency clarity)
IF confidence < 85% → ASK targeted questions, DO NOT finalize
Ask max 2 smart questions at a time:
- Impact: "How many users are affected?"
- Urgency: "Is your work completely blocked?"
- Domain: "Is this related to technical, HR, finance, or service?"
- Time: "When did this issue start?"

═══ EDGE CASE HANDLING ═══
IF no keywords → Default: Customer Support, ask follow-up
IF conflicting signals → Ask clarification BEFORE assigning priority

═══ HARD RULES (NON-NEGOTIABLE) ═══
1. Priority MUST depend on Impact + Urgency with modifiers ONLY
2. SLA MUST match priority exactly (with dynamic compression)
3. NEVER guess missing info — always ask if unclear
4. Department detection happens BEFORE priority
5. Tone can influence urgency but NOT override logic
6. Financial override is absolute: money keywords ≥ 8 → FORCE Finance
7. Default department: Customer Support
8. ALWAYS run all 3 validation checks before output

When chatting with the user, be helpful, conversational, and domain-aware.
Use response personalization based on detected department.
Ask focused, targeted questions if you need more info (max 2 at a time).
If you have enough info to provide a solution, output EXACTLY: SOLUTION: <your detailed solution>
Keep responses concise but thorough.`;

interface TriageResult {
  is_spam: boolean;
  is_contextual_spam: boolean;
  priority: "critical" | "high" | "medium" | "low";
  department: string;
  secondary_department: string;
  category: string;
  sub_category: string;
  impact: "high" | "medium" | "low";
  urgency: "high" | "medium" | "low";
  impact_score: number;
  urgency_score: number;
  confidence_score: number;
  sentiment: string;
  sla_response_time: string;
  sla_resolution_time: string;
  deadline_hours: number;
  agent_suggestion: string;
  clarification_questions: string[];
  priority_modifiers: string[];
  validation_passed: boolean;
  financial_issue: boolean;
  priority_score: number;
  decision_pipeline: string[];
}

/* ── Weighted keyword scoring for mock triage ── */
function scoreDepartment(text: string): { dept: string; score: number; cat: string; subCat: string }[] {
  const t = text.toLowerCase();
  const scores: { dept: string; score: number; cat: string; subCat: string }[] = [];

  /* IT / Technical */
  let itScore = 0;
  if (/login|sign.?in/i.test(t)) itScore += 6;
  if (/system.?error|server.?error/i.test(t)) itScore += 8;
  if (/server.?down|system.?down/i.test(t)) itScore += 10;
  if (/\bbug\b/i.test(t)) itScore += 6;
  if (/\bcrash/i.test(t)) itScore += 8;
  if (/\bapi\b/i.test(t)) itScore += 6;
  if (/\bdatabase\b/i.test(t)) itScore += 6;
  if (/\bslow|latency/i.test(t)) itScore += 4;
  if (/\bnetwork\b/i.test(t)) itScore += 6;
  if (/\binstall/i.test(t)) itScore += 4;
  if (/\bauth/i.test(t)) itScore += 6;
  if (/not.?working|failed.?to.?load|unable.?to.?access/i.test(t)) itScore += 5;
  if (/\bcamera|\bmic\b|\bmicrophone/i.test(t)) itScore += 4;

  let itSubCat = "Feature Not Working";
  if (/login|auth|password|sign.?in/i.test(t)) itSubCat = "Authentication";
  else if (/crash|freeze|hang/i.test(t)) itSubCat = "Application Crash";
  else if (/server|down|unreachable/i.test(t)) itSubCat = "Server/Network";
  else if (/api|integration/i.test(t)) itSubCat = "Integration/API";
  else if (/camera|mic|microphone/i.test(t)) itSubCat = "Device Failure";
  else if (/slow|latency|speed/i.test(t)) itSubCat = "Performance";
  if (itScore > 0) scores.push({ dept: "IT / Technical", score: itScore, cat: "Technical Issue", subCat: itSubCat });

  /* HR */
  let hrScore = 0;
  if (/\bleave\b/i.test(t)) hrScore += 6;
  if (/payroll/i.test(t)) hrScore += 8;
  if (/salary|compensation/i.test(t)) hrScore += 8;
  if (/attendance/i.test(t)) hrScore += 6;
  if (/benefits/i.test(t)) hrScore += 6;
  if (/employee.?id/i.test(t)) hrScore += 6;

  let hrSubCat = "Employee Data Update";
  if (/salary|pay|compensation/i.test(t)) hrSubCat = "Payroll Issue";
  else if (/leave/i.test(t)) hrSubCat = "Leave Request";
  else if (/attendance/i.test(t)) hrSubCat = "Attendance Correction";
  if (hrScore > 0) scores.push({ dept: "HR", score: hrScore, cat: "HR Issue", subCat: hrSubCat });

  /* Finance — high weight keywords */
  let finScore = 0;
  if (/amount.?deducted|money.?deducted/i.test(t)) finScore += 10;
  if (/payment.?failed|failed.?payment/i.test(t)) finScore += 8;
  if (/\brefund\b/i.test(t)) finScore += 6;
  if (/\bbilling\b/i.test(t)) finScore += 8;
  if (/\binvoice\b/i.test(t)) finScore += 6;
  if (/\btransaction\b/i.test(t)) finScore += 6;
  if (/amount.*paid|paid.*amount/i.test(t)) finScore += 8;
  if (/\bpayment\b/i.test(t)) finScore += 6;

  let finSubCat = "Payment Failure";
  if (/refund/i.test(t)) finSubCat = "Refund Issue";
  else if (/invoice|billing/i.test(t)) finSubCat = "Invoice/Billing Error";
  else if (/dispute|charge/i.test(t)) finSubCat = "Transaction Dispute";
  if (finScore > 0) scores.push({ dept: "Finance", score: finScore, cat: "Finance Issue", subCat: finSubCat });

  /* Operations */
  let opsScore = 0;
  if (/\bdelay/i.test(t)) opsScore += 6;
  if (/\bdelivery\b/i.test(t)) opsScore += 6;
  if (/\bprocess\b/i.test(t)) opsScore += 6;
  if (/\bworkflow\b/i.test(t)) opsScore += 6;
  if (/\blogistics\b/i.test(t)) opsScore += 6;
  if (/not.?delivered|process.?stuck/i.test(t)) opsScore += 7;

  let opsSubCat = "Service Delay";
  if (/process.?stuck|workflow/i.test(t)) opsSubCat = "Process Failure";
  else if (/logistics|delivery/i.test(t)) opsSubCat = "Logistics Issue";
  if (opsScore > 0) scores.push({ dept: "Operations", score: opsScore, cat: "Operations Issue", subCat: opsSubCat });

  /* Customer Support */
  let csScore = 0;
  if (/complaint|unhappy|bad.?experience/i.test(t)) csScore += 6;
  if (/not.?satisfied|poor.?service/i.test(t)) csScore += 6;
  if (/\bfeedback\b/i.test(t)) csScore += 4;
  if (/\bcomplaint\b/i.test(t)) csScore += 6;

  if (csScore > 0) scores.push({ dept: "Customer Support", score: csScore, cat: "Customer Issue", subCat: "Complaint" });

  return scores.sort((a, b) => b.score - a.score);
}

/* ── Validation Loop (3 checks) ── */
function runValidationChecks(result: TriageResult, text: string): { passed: boolean; fixes: string[] } {
  const fixes: string[] = [];
  const t = text.toLowerCase();

  /* CHECK 1: payment detected but not Finance */
  if (/payment|refund|amount|billing|invoice|transaction|paid|money/i.test(t) && result.department !== "Finance") {
    result.department = "Finance";
    result.category = "Finance Issue";
    fixes.push("CHECK 1: Payment keywords found → forced department to Finance");
  }

  /* CHECK 2: financial issue but generic suggestion */
  if (result.financial_issue && /troubleshoot|restart|clear cache|browser/i.test(result.agent_suggestion)) {
    result.agent_suggestion = `FINANCIAL ISSUE — Do NOT troubleshoot. Verify transaction in payment gateway, check refund status, escalate to Finance team immediately. Transaction ID needed from user. SLA: ${result.sla_response_time} response.`;
    fixes.push("CHECK 2: Financial issue had generic IT troubleshooting → replaced with finance-specific response");
  }

  /* CHECK 3: urgency low but service completely blocked */
  if (/(blocked|completely|cannot|unable|nothing works|stopped|down)/i.test(t) && result.urgency === "low") {
    result.urgency = "medium";
    result.urgency_score = 2;
    fixes.push("CHECK 3: User reports complete blockage but urgency was low → increased to medium");
  }

  return { passed: fixes.length === 0, fixes };
}

async function aiTriage(
  subject: string,
  description: string,
  chatHistory?: string
): Promise<TriageResult> {
  const text = `${subject} ${description} ${chatHistory || ""}`;
  const lowerText = text.toLowerCase();

  /* Detect financial issue for modifiers */
  const financialIssue = /payment|refund|amount|billing|invoice|transaction|paid|money|deducted|charge/i.test(lowerText);

  const defaultResult: TriageResult = {
    is_spam: false,
    is_contextual_spam: false,
    priority: "medium",
    department: "Customer Support",
    secondary_department: "",
    category: "General Inquiry",
    sub_category: "Unclassified",
    impact: "medium",
    urgency: "medium",
    impact_score: 2,
    urgency_score: 2,
    confidence_score: 60,
    sentiment: "neutral",
    sla_response_time: "1 hour",
    sla_resolution_time: "24 hours",
    deadline_hours: 24,
    agent_suggestion: `Investigate "${subject}". Check system logs, verify user permissions, reproduce the issue, and escalate to appropriate team. Keep the user updated on progress within SLA.`,
    clarification_questions: [],
    priority_modifiers: [],
    validation_passed: true,
    financial_issue: financialIssue,
    priority_score: 4,
    decision_pipeline: ["Signal Extraction", "Domain Detection", "Impact Analysis", "Priority Engine", "Validation"],
  };

  if (!OPENAI_KEY) {
    /* ═══ MOCK v3.0 TRIAGE — Full 5-Layer Engine ═══ */
    const pipeline: string[] = [];

    /* LAYER 1: Signal Extraction */
    pipeline.push("L1: Signal Extraction");
    const hasFinancialSignal = /payment|refund|amount|billing|invoice|transaction|paid|money|deducted/i.test(lowerText);
    const hasUrgencySignal = /urgent|asap|critical|immediately|deadline|blocked/i.test(lowerText);
    /* System signals tracked for confidence scoring */

    /* LAYER 2: Domain Detection (Weighted) */
    pipeline.push("L2: Domain Detection (Weighted)");
    const deptScores = scoreDepartment(text);

    let dept = "Customer Support";
    let cat = "General Inquiry";
    let subCat = "Unclassified";
    let secondaryDept = "";

    if (deptScores.length > 0) {
      dept = deptScores[0].dept;
      cat = deptScores[0].cat;
      subCat = deptScores[0].subCat;
      if (deptScores.length > 1) secondaryDept = deptScores[1].dept;

      /* ⚠️ OVERRIDE: Financial keywords ≥ 8 → FORCE Finance */
      const finEntry = deptScores.find(d => d.dept === "Finance");
      if (finEntry && finEntry.score >= 8 && dept !== "Finance") {
        secondaryDept = dept;
        dept = "Finance";
        cat = finEntry.cat;
        subCat = finEntry.subCat;
        pipeline.push("L2: OVERRIDE → Forced Finance (score ≥ 8)");
      }
    }

    /* LAYER 3: Impact Analysis */
    pipeline.push("L3: Impact Analysis");
    let impactS = 1;
    if (/all users|entire|everyone|whole (team|company|organization)|system down/i.test(text)) impactS = 3;
    else if (/team|department|multiple|several|colleagues/i.test(text)) impactS = 2;
    else impactS = 1;

    /* 💰 Financial Impact Boost */
    if (hasFinancialSignal && impactS < 3) { impactS++; pipeline.push("L3: Financial boost → impact +1"); }

    /* LAYER 4: Priority Engine */
    pipeline.push("L4: Priority Engine (Non-Linear)");
    let urgencyS = 1;
    if (/blocked|urgent|asap|critical|immediately|deadline|down|cannot/i.test(text)) urgencyS = 3;
    else if (/partial|slow|deadline.*24|need.*soon|trying.*hours/i.test(text)) urgencyS = 2;
    else urgencyS = 1;

    /* 🔥 Hidden urgency: paid service not working */
    if (/paid|premium|subscription/i.test(text) && /not working|down|cannot/i.test(text)) {
      urgencyS = 3;
      pipeline.push("L4: Hidden urgency → paid service failure");
    }

    /* Sentiment analysis */
    let sentiment = "neutral";
    const modifiers: string[] = [];
    if (/angry|frustrated|furious|terrible|worst|unacceptable|fix this|ridiculous/i.test(text)) {
      sentiment = "angry"; urgencyS = Math.min(3, urgencyS + 1); modifiers.push("+2 user frustration");
    }
    else if (/anxious|worried|concerned|please help|really need/i.test(text)) { sentiment = "anxious"; }
    else if (/happy|great|thanks|appreciate|awesome/i.test(text)) { sentiment = "satisfied"; }

    /* Apply priority modifiers */
    let baseScore = impactS * urgencyS;
    if (hasFinancialSignal) { baseScore += 2; modifiers.push("+2 financial issue"); }
    if (hasUrgencySignal && !hasFinancialSignal) { baseScore += 3; modifiers.push("+3 business urgency"); }

    /* Priority mapping */
    let priority: "critical" | "high" | "medium" | "low";
    if (baseScore >= 9) priority = "critical";
    else if (baseScore >= 6) priority = "high";
    else if (baseScore >= 3) priority = "medium";
    else priority = "low";

    /* SLA mapping with dynamic compression */
    const slaMap: Record<string, { resp: string; resolve: string; hours: number }> = {
      critical: { resp: "15 minutes", resolve: "2-4 hours", hours: 4 },
      high: { resp: "30 minutes", resolve: "6-8 hours", hours: 8 },
      medium: { resp: "1 hour", resolve: "24 hours", hours: 24 },
      low: { resp: "4 hours", resolve: "48-72 hours", hours: 72 },
    };
    let sla = { ...slaMap[priority] };

    /* Dynamic SLA compression for financial + urgent */
    if (hasFinancialSignal && priority === "high") {
      sla = { resp: "15 minutes", resolve: "4-6 hours", hours: 6 };
      pipeline.push("L4: SLA compressed (financial + urgent)");
    }

    /* LAYER 5: Validation */
    pipeline.push("L5: Validation Loop");

    /* Confidence score */
    let confidence = 70;
    if (deptScores.length > 0 && deptScores[0].score >= 8) confidence = 90;
    else if (deptScores.length > 0 && deptScores[0].score >= 5) confidence = 75;
    else if (deptScores.length === 0) confidence = 40;

    /* Build department-specific agent suggestion */
    let suggestion = "";
    if (dept === "Finance") {
      suggestion = `FINANCIAL ISSUE — Priority: ${priority.toUpperCase()}\n\n1. Verify transaction details in payment gateway\n2. Check refund status if applicable\n3. Cross-reference with billing system\n4. Escalate to Finance team within SLA (${sla.resp} response)\n5. Keep user updated — use reassuring tone\n\nImpact: ${impactS}/3 | Urgency: ${urgencyS}/3 | Base Score: ${baseScore}\nModifiers applied: ${modifiers.join(", ") || "none"}`;
    } else if (dept === "IT / Technical") {
      suggestion = `TECHNICAL ISSUE — Priority: ${priority.toUpperCase()}\n\n1. Check system logs for errors\n2. Verify user permissions and access\n3. Attempt to reproduce the issue\n4. Apply fix or escalate to engineering\n5. Monitor for resolution within SLA (${sla.resolve})\n\nImpact: ${impactS}/3 | Urgency: ${urgencyS}/3 | Base Score: ${baseScore}\nCategory: ${cat} → ${subCat}`;
    } else if (dept === "HR") {
      suggestion = `HR ISSUE — Priority: ${priority.toUpperCase()}\n\n1. Verify employee records in HR system\n2. Check payroll/leave/attendance data\n3. Cross-reference with company policy\n4. Escalate to HR department within SLA\n\nImpact: ${impactS}/3 | Urgency: ${urgencyS}/3 | Base Score: ${baseScore}`;
    } else {
      suggestion = `Priority: ${priority.toUpperCase()} | Dept: ${dept} | ${cat} → ${subCat}\n\nInvestigate "${subject}" thoroughly. Check relevant systems, verify user details, reproduce the issue, and escalate if needed.\nImpact: ${impactS}/3 | Urgency: ${urgencyS}/3 | Score: ${baseScore} | SLA: ${sla.resp} response, ${sla.resolve} resolution.`;
    }

    const result: TriageResult = {
      is_spam: /buy now|click here|free money|lottery|prize|casino|viagra|crypto/i.test(lowerText),
      is_contextual_spam: false,
      priority,
      department: dept,
      secondary_department: secondaryDept,
      category: cat,
      sub_category: subCat,
      impact: impactS === 3 ? "high" : impactS === 2 ? "medium" : "low",
      urgency: urgencyS === 3 ? "high" : urgencyS === 2 ? "medium" : "low",
      impact_score: impactS,
      urgency_score: urgencyS,
      confidence_score: confidence,
      sentiment,
      sla_response_time: sla.resp,
      sla_resolution_time: sla.resolve,
      deadline_hours: sla.hours,
      agent_suggestion: suggestion,
      clarification_questions: [],
      priority_modifiers: modifiers,
      validation_passed: true,
      financial_issue: financialIssue,
      priority_score: baseScore,
      decision_pipeline: pipeline,
    };

    /* Run validation loop */
    const validation = runValidationChecks(result, text);
    result.validation_passed = validation.passed;
    if (!validation.passed) {
      pipeline.push(`L5: FIXES → ${validation.fixes.join("; ")}`);
      result.decision_pipeline = pipeline;
    }

    return result;
  }

  /* ═══ REAL OpenAI v3.0 CALL — Multi-Agent Prompt ═══ */
  const res = await callOpenAI([
    {
      role: "system",
      content: ENTERPRISE_SYSTEM_PROMPT + `\n\nNow classify the following ticket using all 5 layers. You act as 3 agents internally:\n- Agent 1 (Classifier): Extract signals, detect domain with weighted scoring, calculate impact/urgency/priority\n- Agent 2 (Validator): Run 3 validation checks (payment→Finance, financial≠troubleshoot, blocked≠low urgency)\n- Agent 3 (Responder): Generate department-specific agent suggestion\n\nReturn ONLY valid JSON — no markdown, no code fences, no explanation:\n{\n  "department": "primary department",\n  "secondary_department": "secondary department or empty string",\n  "category": "",\n  "sub_category": "",\n  "impact": "high|medium|low",\n  "urgency": "high|medium|low",\n  "impact_score": 1-3,\n  "urgency_score": 1-3,\n  "priority": "critical|high|medium|low",\n  "priority_score": integer,\n  "priority_modifiers": ["list of modifiers applied"],\n  "sla_response_time": "",\n  "sla_resolution_time": "",\n  "confidence_score": 0-100,\n  "sentiment": "angry|frustrated|neutral|satisfied|anxious",\n  "is_spam": false,\n  "is_contextual_spam": false,\n  "financial_issue": true/false,\n  "validation_passed": true/false,\n  "deadline_hours": integer,\n  "agent_suggestion": "department-specific suggestion with reassurance if financial",\n  "clarification_questions": [],\n  "decision_pipeline": ["L1: Signal Extraction", "L2: ...", "L3: ...", "L4: ...", "L5: ..."]\n}`,
    },
    {
      role: "user",
      content: `Subject: ${subject}\nDescription: ${description}${chatHistory ? `\n\nChat History Summary: ${chatHistory}` : ""}`,
    },
  ]);
  try {
    const cleaned = res.replace(/```json\s*|```/g, "").trim();
    const parsed = JSON.parse(cleaned);
    const validP = ["critical", "high", "medium", "low"];
    if (!validP.includes(parsed.priority)) parsed.priority = "medium";
    if (!parsed.secondary_department) parsed.secondary_department = "";
    if (!parsed.priority_modifiers) parsed.priority_modifiers = [];
    if (parsed.validation_passed === undefined) parsed.validation_passed = true;
    if (parsed.financial_issue === undefined) parsed.financial_issue = false;
    if (!parsed.priority_score) parsed.priority_score = (parsed.impact_score || 2) * (parsed.urgency_score || 2);
    if (!parsed.decision_pipeline) parsed.decision_pipeline = ["Signal Extraction", "Domain Detection", "Impact Analysis", "Priority Engine", "Validation"];

    /* Run client-side validation too */
    const result = parsed as TriageResult;
    const validation = runValidationChecks(result, text);
    result.validation_passed = validation.passed;

    return result;
  } catch {
    return defaultResult;
  }
}

/* ═══════════════════════════════════════════════════════════════
   WEBHOOK (best-effort)
   ═══════════════════════════════════════════════════════════════ */

async function sendWebhook(payload: Record<string, unknown>) {
  if (!WEBHOOK_URL) return;
  try {
    await fetch(WEBHOOK_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  } catch {
    /* silent */
  }
}

/* ═══════════════════════════════════════════════════════════════
   BADGE HELPERS
   ═══════════════════════════════════════════════════════════════ */

function priorityBadge(p: string) {
  if (p === "critical") return "bg-red-200 text-red-900 border-red-400 ring-2 ring-red-300";
  if (p === "high") return "bg-rose-100 text-rose-700 border-rose-200";
  if (p === "medium") return "bg-amber-100 text-amber-700 border-amber-200";
  return "bg-emerald-100 text-emerald-700 border-emerald-200";
}
function statusBadge(s: string) {
  const m: Record<string, string> = {
    open: "bg-sky-100 text-sky-700 border-sky-200",
    in_progress: "bg-violet-100 text-violet-700 border-violet-200",
    resolved: "bg-emerald-100 text-emerald-700 border-emerald-200",
    spam: "bg-slate-100 text-slate-500 border-slate-200",
  };
  return m[s] || "bg-slate-100 text-slate-500";
}
function priorityDot(p: string) {
  if (p === "critical") return "bg-red-600";
  if (p === "high") return "bg-rose-500";
  if (p === "medium") return "bg-amber-500";
  return "bg-emerald-500";
}

/* ═══════════════════════════════════════════════════════════════
   STAR RATING COMPONENT
   ═══════════════════════════════════════════════════════════════ */

function StarRating({
  value,
  onChange,
}: {
  value: number;
  onChange: (v: number) => void;
}) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((s) => (
        <button
          key={s}
          type="button"
          onClick={() => onChange(s)}
          onMouseEnter={() => setHover(s)}
          onMouseLeave={() => setHover(0)}
          className="text-2xl transition-transform hover:scale-125"
        >
          <span
            className={
              s <= (hover || value) ? "text-amber-400" : "text-slate-300"
            }
          >
            ★
          </span>
        </button>
      ))}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   TOP NAV BAR
   ═══════════════════════════════════════════════════════════════ */

function TopNav({
  session,
  onLogout,
}: {
  session: Session;
  onLogout: () => void;
}) {
  return (
    <nav className="sticky top-0 z-50 border-b border-slate-200 bg-white/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-3">
        <div className="flex items-center gap-2.5">
          <img src="/logo.png" alt="PRiorix" className="h-8 w-8 rounded-lg" />
          <span className="text-lg font-extrabold tracking-tight text-slate-900">
            PRiorix
          </span>
        </div>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-2 text-sm text-slate-600">
            <span
              className={`inline-block h-2 w-2 rounded-full ${
                session.role === "admin" ? "bg-violet-500" : "bg-sky-500"
              }`}
            />
            {session.name}
            <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-500">
              {session.role === "admin" ? "Admin" : "User"}
            </span>
          </span>
          <button
            onClick={onLogout}
            className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-50"
          >
            Sign Out
          </button>
        </div>
      </div>
    </nav>
  );
}

/* ═══════════════════════════════════════════════════════════════
   LANDING PAGE
   ═══════════════════════════════════════════════════════════════ */

function LandingPage({ onNavigate }: { onNavigate: (p: Page) => void }) {
  return (
    <div className="min-h-screen bg-white">
      {/* Gradient blobs */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute -left-32 -top-32 h-[500px] w-[500px] rounded-full bg-gradient-to-br from-sky-200/60 to-violet-200/60 blur-3xl" />
        <div className="pointer-events-none absolute bottom-0 right-0 h-[400px] w-[400px] rounded-full bg-gradient-to-tl from-rose-200/40 to-violet-200/40 blur-3xl" />

        {/* Nav */}
        <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="PRiorix" className="h-10 w-10 rounded-xl" />
            <span className="text-xl font-extrabold tracking-tight text-slate-900">
              PRiorix
            </span>
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => onNavigate("login")}
              className="rounded-xl border border-slate-300 px-5 py-2 text-sm font-semibold text-slate-700 transition hover:-translate-y-0.5 hover:border-slate-400 hover:bg-slate-50"
            >
              Sign In
            </button>
            <button
              onClick={() => onNavigate("signup")}
              className="rounded-xl bg-sky-500 px-5 py-2 text-sm font-semibold text-white shadow-md shadow-sky-200 transition hover:-translate-y-0.5 hover:bg-sky-600"
            >
              Get Started
            </button>
          </div>
        </nav>

        {/* Hero */}
        <div className="mx-auto flex max-w-6xl flex-col items-center gap-6 px-6 pb-24 pt-16 text-center md:pt-24">
          <div className="animate-fade-in">
            <img
              src="/logo.png"
              alt="PRiorix"
              className="mx-auto mb-4 h-24 w-24 rounded-2xl shadow-lg shadow-sky-200/50"
            />
          </div>

          <h1 className="animate-fade-in-up text-5xl font-black tracking-tight text-slate-900 md:text-7xl">
            <span className="bg-gradient-to-r from-sky-500 via-violet-500 to-rose-500 bg-clip-text text-transparent">
              PRiorix
            </span>
          </h1>

          <p className="animate-fade-in-up [animation-delay:100ms] max-w-2xl text-2xl font-semibold text-slate-700 md:text-3xl">
            AI-Powered Support Intelligence Platform
          </p>

          <p className="animate-fade-in-up [animation-delay:200ms] max-w-xl text-base text-slate-500">
            Resolve issues instantly with guided AI chat, route unresolved cases
            with priority intelligence, and close the loop with dashboards and
            feedback.
          </p>

          <div className="animate-fade-in-up [animation-delay:300ms] mt-4 flex gap-4">
            <button
              onClick={() => onNavigate("signup")}
              className="rounded-2xl bg-gradient-to-r from-sky-500 to-violet-500 px-8 py-3.5 text-base font-bold text-white shadow-lg shadow-sky-300/40 transition hover:-translate-y-1 hover:shadow-xl hover:shadow-sky-300/50"
            >
              Start Free →
            </button>
            <button
              onClick={() => onNavigate("login")}
              className="rounded-2xl border border-slate-300 px-8 py-3.5 text-base font-semibold text-slate-700 transition hover:-translate-y-1 hover:bg-slate-50"
            >
              Sign In
            </button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-6xl px-6 pb-24">
        <div className="grid gap-6 md:grid-cols-3">
          {[
            {
              icon: "🤖",
              title: "AI Chat Resolution",
              desc: "Instantly analyze issues and resolve them through guided AI conversation.",
              color: "from-sky-50 to-sky-100 border-sky-200",
              shadow: "hover:shadow-sky-200/50",
            },
            {
              icon: "🎯",
              title: "Smart Triage",
              desc: "Auto-classify priority, department, spam detection, and deadline estimation.",
              color: "from-violet-50 to-violet-100 border-violet-200",
              shadow: "hover:shadow-violet-200/50",
            },
            {
              icon: "📊",
              title: "Live Analytics",
              desc: "Real-time dashboards with priority distribution and ticket trends.",
              color: "from-rose-50 to-rose-100 border-rose-200",
              shadow: "hover:shadow-rose-200/50",
            },
          ].map((f) => (
            <div
              key={f.title}
              className={`card-3d group rounded-2xl border bg-gradient-to-br p-6 transition duration-300 ${f.color} ${f.shadow} hover:-translate-y-1 hover:shadow-lg`}
            >
              <div className="mb-4 text-4xl">{f.icon}</div>
              <h3 className="mb-2 text-lg font-bold text-slate-900">
                {f.title}
              </h3>
              <p className="text-sm text-slate-600">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-slate-200 py-8 text-center text-sm text-slate-500">
        © {new Date().getFullYear()} PRiorix — AI-Powered Support Intelligence
      </footer>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   LOGIN PAGE
   ═══════════════════════════════════════════════════════════════ */

function LoginPage({
  onNavigate,
  onAuth,
}: {
  onNavigate: (p: Page) => void;
  onAuth: (session: Session) => void;
}) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);

    // Small delay for UX
    await new Promise((r) => setTimeout(r, 400));

    const users = getUsers();
    const user = users.find(
      (u) =>
        u.email.toLowerCase() === email.toLowerCase() &&
        u.password === password
    );

    if (!user) {
      setError("Invalid email or password.");
      setLoading(false);
      return;
    }

    const session: Session = {
      userId: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
    };
    save(LS_SESSION, session);
    onAuth(session);
    setLoading(false);
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-50 via-white to-sky-50 px-4">
      <div className="pointer-events-none absolute left-10 top-10 h-72 w-72 rounded-full bg-sky-200/30 blur-3xl" />
      <div className="pointer-events-none absolute bottom-10 right-10 h-72 w-72 rounded-full bg-violet-200/30 blur-3xl" />

      <div className="card-3d relative w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 shadow-xl">
        <div className="mb-6 flex flex-col items-center">
          <img src="/logo.png" alt="PRiorix" className="mb-3 h-14 w-14 rounded-xl" />
          <h2 className="text-2xl font-bold text-slate-900">Welcome Back</h2>
          <p className="mt-1 text-sm text-slate-500">
            Sign in to your account
          </p>
        </div>

        {error && (
          <div className="mb-4 rounded-lg border border-rose-200 bg-rose-50 px-4 py-2.5 text-sm text-rose-700">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="mb-1 block text-sm font-medium text-slate-700">
              Email
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm outline-none transition focus:border-sky-400 focus:ring-2 focus:ring-sky-100"
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-slate-700">
              Password
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm outline-none transition focus:border-sky-400 focus:ring-2 focus:ring-sky-100"
              placeholder="••••••••"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-gradient-to-r from-sky-500 to-violet-500 py-2.5 text-sm font-bold text-white shadow-md transition hover:shadow-lg disabled:opacity-60"
          >
            {loading ? "Signing in…" : "Sign In"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-slate-500">
          Don&apos;t have an account?{" "}
          <button
            onClick={() => onNavigate("signup")}
            className="font-semibold text-sky-600 hover:text-sky-700"
          >
            Sign Up
          </button>
        </p>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SIGNUP PAGE  (User only — admin is pre-created)
   ═══════════════════════════════════════════════════════════════ */

function SignupPage({
  onNavigate,
  onAuth,
}: {
  onNavigate: (p: Page) => void;
  onAuth: (session: Session) => void;
}) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    await new Promise((r) => setTimeout(r, 400));

    if (email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
      setError("This email is reserved. Please use a different email.");
      setLoading(false);
      return;
    }

    const users = getUsers();
    if (users.find((u) => u.email.toLowerCase() === email.toLowerCase())) {
      setError("An account with this email already exists.");
      setLoading(false);
      return;
    }

    const newUser: AppUser = {
      id: genId(),
      name,
      email,
      password,
      role: "user",
      createdAt: new Date().toISOString(),
    };
    users.push(newUser);
    save(LS_USERS, users);

    const session: Session = {
      userId: newUser.id,
      name: newUser.name,
      email: newUser.email,
      role: newUser.role,
    };
    save(LS_SESSION, session);
    onAuth(session);
    setLoading(false);
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-50 via-white to-violet-50 px-4">
      <div className="pointer-events-none absolute right-10 top-10 h-72 w-72 rounded-full bg-violet-200/30 blur-3xl" />
      <div className="pointer-events-none absolute bottom-10 left-10 h-72 w-72 rounded-full bg-sky-200/30 blur-3xl" />

      <div className="card-3d relative w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 shadow-xl">
        <div className="mb-6 flex flex-col items-center">
          <img src="/logo.png" alt="PRiorix" className="mb-3 h-14 w-14 rounded-xl" />
          <h2 className="text-2xl font-bold text-slate-900">Create Account</h2>
          <p className="mt-1 text-sm text-slate-500">
            Join PRiorix as a user
          </p>
        </div>

        {error && (
          <div className="mb-4 rounded-lg border border-rose-200 bg-rose-50 px-4 py-2.5 text-sm text-rose-700">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="mb-1 block text-sm font-medium text-slate-700">
              Full Name
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm outline-none transition focus:border-violet-400 focus:ring-2 focus:ring-violet-100"
              placeholder="John Doe"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-slate-700">
              Email
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm outline-none transition focus:border-violet-400 focus:ring-2 focus:ring-violet-100"
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-slate-700">
              Password
            </label>
            <input
              type="password"
              required
              minLength={4}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm outline-none transition focus:border-violet-400 focus:ring-2 focus:ring-violet-100"
              placeholder="••••••••"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-gradient-to-r from-violet-500 to-sky-500 py-2.5 text-sm font-bold text-white shadow-md transition hover:shadow-lg disabled:opacity-60"
          >
            {loading ? "Creating account…" : "Create Account"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-slate-500">
          Already have an account?{" "}
          <button
            onClick={() => onNavigate("login")}
            className="font-semibold text-violet-600 hover:text-violet-700"
          >
            Sign In
          </button>
        </p>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   USER DASHBOARD
   ═══════════════════════════════════════════════════════════════ */

function UserDashboard({
  session,
  onLogout,
}: {
  session: Session;
  onLogout: () => void;
}) {
  const [tab, setTab] = useState<"submit" | "tickets">("submit");

  /* ── Submit Issue state ── */
  const [subject, setSubject] = useState("");
  const [description, setDescription] = useState("");
  const [attachment, setAttachment] = useState("");
  const [chatActive, setChatActive] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMsg[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const [solution, setSolution] = useState<string | null>(null);
  const [escalated, setEscalated] = useState(false);
  const [escalationResult, setEscalationResult] = useState<Ticket | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  /* ── My Tickets state ── */
  const [userTickets, setUserTickets] = useState<Ticket[]>([]);
  const [feedbackMap, setFeedbackMap] = useState<Record<string, Feedback>>({});

  /* ── Feedback form state ── */
  const [fbTicketId, setFbTicketId] = useState<string | null>(null);
  const [fbRating, setFbRating] = useState(0);
  const [fbComment, setFbComment] = useState("");
  const [fbSuccess, setFbSuccess] = useState(false);

  /* ── Email service ── */
  const { emailStatus, emailTicketCreated } = useEmailService();

  useEffect(() => {
    refreshTickets();
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages, solution]);

  function refreshTickets() {
    const all = getTickets();
    const mine = all
      .filter((t) => t.userEmail === session.email)
      .sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    setUserTickets(mine);

    const fbs = getFeedbacks();
    const map: Record<string, Feedback> = {};
    fbs.forEach((f) => (map[f.ticketId] = f));
    setFeedbackMap(map);
  }

  /* ────────── CHAT LOGIC ────────── */

  const SYSTEM_PROMPT: ChatMsg = {
    role: "system",
    content: ENTERPRISE_SYSTEM_PROMPT,
  };

  async function startChat() {
    if (!subject.trim()) return;
    setChatActive(true);
    setEscalated(false);
    setEscalationResult(null);
    setSolution(null);
    setChatMessages([]);

    const msgs: ChatMsg[] = [
      SYSTEM_PROMPT,
      { role: "user", content: `${subject}\n\n${description}` },
    ];
    setChatMessages(msgs);
    setChatLoading(true);

    try {
      const reply = await callOpenAI(msgs);
      const assistantMsg: ChatMsg = { role: "assistant", content: reply };
      const updated = [...msgs, assistantMsg];
      setChatMessages(updated);

      if (reply.startsWith("SOLUTION:")) {
        setSolution(reply.replace("SOLUTION:", "").trim());
      }
    } catch {
      setChatMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "Sorry, I encountered an error. Please try again.",
        },
      ]);
    }
    setChatLoading(false);
  }

  async function sendChat() {
    if (!chatInput.trim() || chatLoading) return;
    const userMsg: ChatMsg = { role: "user", content: chatInput };
    const updated = [...chatMessages, userMsg];
    setChatMessages(updated);
    setChatInput("");
    setChatLoading(true);

    try {
      const reply = await callOpenAI(updated);
      const assistantMsg: ChatMsg = { role: "assistant", content: reply };
      setChatMessages([...updated, assistantMsg]);

      if (reply.startsWith("SOLUTION:")) {
        setSolution(reply.replace("SOLUTION:", "").trim());
      }
    } catch {
      setChatMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "Sorry, I encountered an error. Please try again.",
        },
      ]);
    }
    setChatLoading(false);
  }

  async function handleSolved() {
    // Log as solved interaction (just mark it, no ticket needed)
    setEscalated(false);
    setChatActive(false);
    setSolution(null);
    setSubject("");
    setDescription("");
    setAttachment("");
    alert("✅ Great! Your issue has been marked as resolved.");
  }

  async function handleEscalate() {
    setEscalated(true);
    setChatLoading(true);
    try {
      /* Build chat summary for better classification */
      const chatSummary = chatMessages
        .filter((m) => m.role !== "system")
        .map((m) => `${m.role}: ${m.content}`)
        .join(" | ");

      const triage = await aiTriage(subject, description, chatSummary);

      const deadlineDate = new Date(
        Date.now() + (triage.deadline_hours || 48) * 3600000
      );

      const validPriorities = ["critical", "high", "medium", "low"];
      const ticket: Ticket = {
        id: genId(),
        subject,
        description,
        attachments: attachment || "",
        status: "open",
        priority: (validPriorities.includes(triage.priority)
          ? triage.priority
          : "medium") as Ticket["priority"],
        department: triage.department || "Customer Support",
        deadline: deadlineDate.toISOString(),
        aiSuggestion: triage.agent_suggestion || "",
        isSpam: !!triage.is_spam,
        userEmail: session.email,
        createdAt: new Date().toISOString(),
        category: triage.category || "General",
        subCategory: triage.sub_category || "Unclassified",
        impact: triage.impact || "medium",
        urgency: triage.urgency || "medium",
        impactScore: triage.impact_score || 2,
        urgencyScore: triage.urgency_score || 2,
        confidenceScore: triage.confidence_score || 70,
        sentiment: triage.sentiment || "neutral",
        slaResponseTime: triage.sla_response_time || "1 hour",
        slaResolutionTime: triage.sla_resolution_time || "24 hours",
        clarificationQuestions: triage.clarification_questions || [],
        /* v3.0 Ultra-Advanced fields */
        secondaryDepartment: triage.secondary_department || "",
        priorityModifiers: triage.priority_modifiers || [],
        validationPassed: triage.validation_passed !== false,
        financialIssue: !!triage.financial_issue,
        priorityScore: triage.priority_score || (triage.impact_score || 2) * (triage.urgency_score || 2),
        decisionPipeline: triage.decision_pipeline || [],
      };

      const tickets = getTickets();
      tickets.push(ticket);
      save(LS_TICKETS, tickets);

      setEscalationResult(ticket);

      sendWebhook({
        event_type: "ticket_created",
        user_email: session.email,
        ticket_id: ticket.id,
        is_spam: ticket.isSpam,
        priority: ticket.priority,
      });

      /* 📧 Send ticket confirmation email to user (+ admin alert if high priority) */
      emailTicketCreated(ticket, session.name);

      refreshTickets();
    } catch {
      alert("Error creating ticket. Please try again.");
    }
    setChatLoading(false);
  }

  function resetChat() {
    setChatActive(false);
    setChatMessages([]);
    setSolution(null);
    setEscalated(false);
    setEscalationResult(null);
    setSubject("");
    setDescription("");
    setAttachment("");
  }

  async function submitFeedback() {
    if (!fbTicketId || fbRating === 0) return;
    const fb: Feedback = {
      id: genId(),
      ticketId: fbTicketId,
      rating: fbRating,
      comment: fbComment,
      createdAt: new Date().toISOString(),
    };
    const fbs = getFeedbacks();
    fbs.push(fb);
    save(LS_FEEDBACK, fbs);

    setFbTicketId(null);
    setFbRating(0);
    setFbComment("");
    setFbSuccess(true);
    setTimeout(() => setFbSuccess(false), 3000);
    refreshTickets();
  }

  /* ────────── RENDER ────────── */

  return (
    <div className="min-h-screen bg-slate-50">
      <TopNav session={session} onLogout={onLogout} />

      <div className="mx-auto max-w-6xl px-6 py-8">
        {/* Tabs */}
        <div className="mb-6 flex gap-1 rounded-xl bg-white p-1 shadow-sm border border-slate-200 w-fit">
          {(["submit", "tickets"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`rounded-lg px-5 py-2 text-sm font-semibold transition ${
                tab === t
                  ? "bg-sky-500 text-white shadow"
                  : "text-slate-600 hover:bg-slate-100"
              }`}
            >
              {t === "submit" ? "📝 Submit Issue" : "🎫 My Tickets"}
            </button>
          ))}
        </div>

        {fbSuccess && (
          <div className="mb-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
            ✅ Feedback submitted successfully!
          </div>
        )}

        {/* ─── SUBMIT TAB ─── */}
        {tab === "submit" && (
          <div className="space-y-6">
            {!chatActive ? (
              /* Issue Form */
              <div className="card-3d rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <h2 className="mb-4 text-xl font-bold text-slate-900">
                  Describe Your Issue
                </h2>
                <div className="space-y-4">
                  <div>
                    <label className="mb-1 block text-sm font-medium text-slate-700">
                      Subject *
                    </label>
                    <input
                      type="text"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm outline-none transition focus:border-sky-400 focus:ring-2 focus:ring-sky-100"
                      placeholder="Brief description of your issue"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-slate-700">
                      Description *
                    </label>
                    <textarea
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      rows={4}
                      className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm outline-none transition focus:border-sky-400 focus:ring-2 focus:ring-sky-100"
                      placeholder="Provide details about your issue..."
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-slate-700">
                      Attachment (filename or URL)
                    </label>
                    <input
                      type="text"
                      value={attachment}
                      onChange={(e) => setAttachment(e.target.value)}
                      className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm outline-none transition focus:border-sky-400 focus:ring-2 focus:ring-sky-100"
                      placeholder="e.g. screenshot.png"
                    />
                  </div>
                  <button
                    onClick={startChat}
                    disabled={!subject.trim()}
                    className="rounded-xl bg-gradient-to-r from-sky-500 to-violet-500 px-6 py-2.5 text-sm font-bold text-white shadow-md transition hover:shadow-lg disabled:opacity-50"
                  >
                    Start AI Chat →
                  </button>
                </div>
              </div>
            ) : (
              /* Chat Interface */
              <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
                {/* Chat header */}
                <div className="flex items-center justify-between border-b border-slate-200 bg-gradient-to-r from-sky-50 to-violet-50 px-6 py-3">
                  <div className="flex items-center gap-2">
                    <img src="/logo.png" alt="" className="h-6 w-6 rounded-md" />
                    <span className="text-sm font-bold text-slate-800">
                      PRiorix AI Assistant
                    </span>
                  </div>
                  <button
                    onClick={resetChat}
                    className="text-xs text-slate-500 hover:text-slate-700"
                  >
                    ✕ Close
                  </button>
                </div>

                {/* Messages */}
                <div className="h-96 overflow-y-auto p-4 space-y-3">
                  {chatMessages
                    .filter((m) => m.role !== "system")
                    .map((m, i) => (
                      <div
                        key={i}
                        className={`flex ${
                          m.role === "user" ? "justify-end" : "justify-start"
                        }`}
                      >
                        <div
                          className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${
                            m.role === "user"
                              ? "bg-sky-500 text-white"
                              : "bg-slate-100 text-slate-800"
                          }`}
                        >
                          {m.content}
                        </div>
                      </div>
                    ))}
                  {chatLoading && (
                    <div className="flex justify-start">
                      <div className="rounded-2xl bg-slate-100 px-4 py-2.5 text-sm text-slate-500">
                        <span className="inline-flex gap-1">
                          <span className="animate-bounce">●</span>
                          <span className="animate-bounce [animation-delay:0.1s]">
                            ●
                          </span>
                          <span className="animate-bounce [animation-delay:0.2s]">
                            ●
                          </span>
                        </span>
                      </div>
                    </div>
                  )}
                  <div ref={chatEndRef} />
                </div>

                {/* Solution Banner */}
                {solution && !escalated && (
                  <div className="border-t border-emerald-200 bg-emerald-50 p-4">
                    <div className="mb-3 flex items-center gap-2 text-sm font-bold text-emerald-800">
                      <span>💡</span> Solution Found
                    </div>
                    <p className="mb-4 text-sm text-emerald-700 whitespace-pre-line">
                      {solution}
                    </p>
                    <p className="mb-2 text-xs font-semibold text-emerald-700">
                      Did this solve your problem?
                    </p>
                    <div className="flex gap-3">
                      <button
                        onClick={handleSolved}
                        className="rounded-lg bg-emerald-500 px-4 py-2 text-sm font-bold text-white transition hover:bg-emerald-600"
                      >
                        ✅ Yes, this worked
                      </button>
                      <button
                        onClick={handleEscalate}
                        className="rounded-lg border border-amber-300 bg-amber-50 px-4 py-2 text-sm font-bold text-amber-700 transition hover:bg-amber-100"
                      >
                        ❌ No, I still need help
                      </button>
                    </div>
                  </div>
                )}

                {/* Escalation result — v3.0 Ultra-Advanced Classification */}
                {escalated && escalationResult && (
                  <div className="border-t border-violet-200 bg-gradient-to-b from-violet-50 to-slate-50 p-4">
                    <div className="mb-3 flex items-center justify-between">
                      <div className="flex items-center gap-2 text-sm font-bold text-violet-800">
                        <span>🎫</span> Ticket Created — v3.0 Decision Engine
                      </div>
                      {escalationResult.validationPassed && (
                        <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-700">✓ Validated</span>
                      )}
                    </div>

                    {/* Ticket ID + Priority + Score */}
                    <div className="mb-3 flex items-center justify-between rounded-lg bg-white p-3 shadow-sm border border-slate-100">
                      <div>
                        <span className="text-xs text-slate-500">Ticket ID</span>
                        <div className="font-mono text-sm font-bold text-slate-800">{escalationResult.id.slice(0, 8)}</div>
                      </div>
                      <div className="text-center">
                        <span className="text-xs text-slate-500">Priority Score</span>
                        <div className="text-lg font-black text-slate-800">{escalationResult.priorityScore}</div>
                      </div>
                      <div className="text-right">
                        <span className="text-xs text-slate-500">Priority</span>
                        <div>
                          <span className={`inline-block rounded-full border px-3 py-1 text-xs font-bold ${priorityBadge(escalationResult.priority)}`}>
                            {escalationResult.priority.toUpperCase()}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Financial Issue Alert */}
                    {escalationResult.financialIssue && (
                      <div className="mb-3 rounded-lg border border-amber-300 bg-gradient-to-r from-amber-50 to-orange-50 p-2.5 text-xs">
                        <div className="flex items-center gap-2 font-bold text-amber-800">
                          <span>💰</span> Financial Issue Detected — Finance department enforced, reassurance tone applied
                        </div>
                        {escalationResult.priorityModifiers.length > 0 && (
                          <div className="mt-1 text-amber-700">Modifiers: {escalationResult.priorityModifiers.join(" | ")}</div>
                        )}
                      </div>
                    )}

                    {/* Classification Grid */}
                    <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                      <div className="rounded-lg bg-white p-2 border border-slate-100">
                        <span className="text-xs text-slate-400">Department</span>
                        <div className="font-semibold text-slate-700">{escalationResult.department}</div>
                        {escalationResult.secondaryDepartment && (
                          <div className="text-[10px] text-slate-400">+ {escalationResult.secondaryDepartment}</div>
                        )}
                      </div>
                      <div className="rounded-lg bg-white p-2 border border-slate-100">
                        <span className="text-xs text-slate-400">Category</span>
                        <div className="font-semibold text-slate-700">{escalationResult.category || "General"}</div>
                        <div className="text-[10px] text-slate-400">{escalationResult.subCategory}</div>
                      </div>
                      <div className="rounded-lg bg-white p-2 border border-slate-100">
                        <span className="text-xs text-slate-400">Sentiment</span>
                        <div className="font-semibold text-slate-700 capitalize">
                          {escalationResult.sentiment === "angry" ? "😠 Angry" :
                           escalationResult.sentiment === "frustrated" ? "😤 Frustrated" :
                           escalationResult.sentiment === "anxious" ? "😟 Anxious" :
                           escalationResult.sentiment === "satisfied" ? "😊 Satisfied" : "😐 Neutral"}
                        </div>
                      </div>
                      <div className="rounded-lg bg-white p-2 border border-slate-100">
                        <span className="text-xs text-slate-400">Validation</span>
                        <div className={`font-semibold ${escalationResult.validationPassed ? "text-emerald-600" : "text-amber-600"}`}>
                          {escalationResult.validationPassed ? "✅ All checks passed" : "⚠️ Auto-corrected"}
                        </div>
                      </div>
                    </div>

                    {/* Impact × Urgency + Modifiers */}
                    <div className="mb-3 rounded-lg bg-white p-3 border border-slate-100">
                      <div className="mb-2 text-xs font-bold text-slate-500 uppercase tracking-wide">Impact × Urgency + Modifiers</div>
                      <div className="grid grid-cols-5 gap-1 text-center text-xs">
                        <div className={`rounded-lg p-2 ${escalationResult.impact === "high" ? "bg-rose-100 text-rose-700 font-bold" : "bg-slate-50 text-slate-500"}`}>
                          <div className="text-lg">{escalationResult.impactScore}</div><div>Impact</div>
                        </div>
                        <div className="text-lg font-bold text-slate-300 flex items-center justify-center">×</div>
                        <div className={`rounded-lg p-2 ${escalationResult.urgency === "high" ? "bg-amber-100 text-amber-700 font-bold" : escalationResult.urgency === "medium" ? "bg-amber-50 text-amber-600" : "bg-slate-50 text-slate-500"}`}>
                          <div className="text-lg">{escalationResult.urgencyScore}</div><div>Urgency</div>
                        </div>
                        <div className="text-lg font-bold text-slate-300 flex items-center justify-center">+</div>
                        <div className="rounded-lg bg-violet-50 p-2 text-violet-700 font-bold">
                          <div className="text-lg">{escalationResult.priorityModifiers.length}</div><div>Mods</div>
                        </div>
                      </div>
                      {escalationResult.priorityModifiers.length > 0 && (
                        <div className="mt-2 flex flex-wrap gap-1">
                          {escalationResult.priorityModifiers.map((m, i) => (
                            <span key={i} className="rounded-full bg-violet-100 px-2 py-0.5 text-[10px] font-semibold text-violet-700">{m}</span>
                          ))}
                        </div>
                      )}
                      <div className="mt-2 text-center text-xs text-slate-500">
                        Score: {escalationResult.priorityScore} → <span className="font-bold">{escalationResult.priority.toUpperCase()}</span>
                      </div>
                    </div>

                    {/* Decision Pipeline */}
                    {escalationResult.decisionPipeline.length > 0 && (
                      <div className="mb-3 rounded-lg bg-white p-2 border border-slate-100">
                        <div className="text-xs font-bold text-slate-500 mb-1.5">Decision Pipeline</div>
                        <div className="flex flex-wrap gap-1">
                          {escalationResult.decisionPipeline.map((step, i) => (
                            <span key={i} className="flex items-center gap-1 text-[10px]">
                              <span className="rounded-full bg-slate-100 px-1.5 py-0.5 font-medium text-slate-600">{step}</span>
                              {i < escalationResult.decisionPipeline.length - 1 && <span className="text-slate-300">→</span>}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* SLA Timeline */}
                    <div className="mb-3 grid grid-cols-2 gap-2">
                      <div className="rounded-lg bg-sky-50 border border-sky-200 p-2 text-center">
                        <div className="text-xs text-sky-500">SLA Response</div>
                        <div className="text-sm font-bold text-sky-700">{escalationResult.slaResponseTime || "1 hour"}</div>
                      </div>
                      <div className="rounded-lg bg-violet-50 border border-violet-200 p-2 text-center">
                        <div className="text-xs text-violet-500">SLA Resolution</div>
                        <div className="text-sm font-bold text-violet-700">{escalationResult.slaResolutionTime || "24 hours"}</div>
                      </div>
                    </div>

                    {/* Confidence Score Bar */}
                    <div className="mb-3 rounded-lg bg-white p-2 border border-slate-100">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-slate-500">AI Confidence</span>
                        <span className="font-bold">{escalationResult.confidenceScore}%</span>
                      </div>
                      <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                        <div className={`h-full rounded-full transition-all ${escalationResult.confidenceScore >= 80 ? "bg-emerald-500" : escalationResult.confidenceScore >= 50 ? "bg-amber-500" : "bg-rose-500"}`} style={{ width: `${escalationResult.confidenceScore || 70}%` }} />
                      </div>
                    </div>

                    {/* Deadline */}
                    <div className="mb-3 text-sm">
                      <span className="text-slate-500">Deadline:</span>{" "}
                      <span className="font-semibold">{new Date(escalationResult.deadline).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" })}</span>
                    </div>

                    {/* Email status */}
                    {emailStatus.lastType === "ticket_created" && (
                      <div className={`mb-2 rounded-lg px-3 py-2 text-xs font-medium ${emailStatus.sending ? "bg-sky-50 text-sky-700" : emailStatus.lastResult === "success" ? "bg-emerald-50 text-emerald-700" : emailStatus.lastResult === "not_configured" ? "bg-sky-50 text-sky-700" : "bg-amber-50 text-amber-700"}`}>
                        {emailStatus.sending ? "📧 Sending confirmation email…" : emailStatus.lastMessage}
                      </div>
                    )}
                    {(escalationResult.priority === "high" || escalationResult.priority === "critical") && (
                      <div className="mb-2 rounded-lg bg-rose-50 px-3 py-2 text-xs font-medium text-rose-700">
                        🚨 {escalationResult.priority === "critical" ? "CRITICAL" : "High"} priority — Admin alert triggered immediately
                      </div>
                    )}
                    <button onClick={resetChat} className="mt-2 rounded-lg bg-violet-500 px-4 py-2 text-sm font-bold text-white transition hover:bg-violet-600">
                      Back to Dashboard
                    </button>
                  </div>
                )}

                {/* Escalation loading */}
                {escalated && !escalationResult && chatLoading && (
                  <div className="border-t border-violet-200 bg-violet-50 p-4 text-sm text-violet-600">
                    Creating ticket and analyzing priority…
                  </div>
                )}

                {/* Chat input (only when no solution yet) */}
                {!solution && !escalated && (
                  <div className="flex gap-2 border-t border-slate-200 p-3">
                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && sendChat()}
                      disabled={chatLoading}
                      className="flex-1 rounded-xl border border-slate-300 px-4 py-2 text-sm outline-none transition focus:border-sky-400 focus:ring-2 focus:ring-sky-100 disabled:opacity-50"
                      placeholder="Type your reply…"
                    />
                    <button
                      onClick={sendChat}
                      disabled={chatLoading || !chatInput.trim()}
                      className="rounded-xl bg-sky-500 px-4 py-2 text-sm font-bold text-white transition hover:bg-sky-600 disabled:opacity-50"
                    >
                      Send
                    </button>
                    <button
                      onClick={handleEscalate}
                      disabled={chatLoading}
                      className="rounded-xl border border-amber-300 bg-amber-50 px-3 py-2 text-xs font-bold text-amber-700 transition hover:bg-amber-100 disabled:opacity-50"
                      title="Skip to creating a ticket"
                    >
                      Escalate
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ─── MY TICKETS TAB ─── */}
        {tab === "tickets" && (
          <div className="space-y-4">
            {userTickets.length === 0 ? (
              <div className="card-3d rounded-2xl border border-slate-200 bg-white p-12 text-center shadow-sm">
                <div className="text-5xl mb-3">📭</div>
                <h3 className="text-lg font-bold text-slate-900">
                  No tickets yet
                </h3>
                <p className="text-sm text-slate-500">
                  Submit an issue to get started!
                </p>
              </div>
            ) : (
              userTickets.map((ticket) => (
                <div
                  key={ticket.id}
                  className="card-3d rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="flex items-center gap-1.5">
                          <span
                            className={`inline-block h-2 w-2 rounded-full ${priorityDot(
                              ticket.priority
                            )}`}
                          />
                          <span
                            className={`rounded-full border px-2 py-0.5 text-xs font-semibold ${priorityBadge(
                              ticket.priority
                            )}`}
                          >
                            {ticket.priority.toUpperCase()}
                          </span>
                        </span>
                        <span
                          className={`rounded-full border px-2 py-0.5 text-xs font-semibold ${statusBadge(
                            ticket.status
                          )}`}
                        >
                          {ticket.status.replace("_", " ").toUpperCase()}
                        </span>
                        <span className="text-xs text-slate-400">
                          {new Date(ticket.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <h3 className="font-bold text-slate-900">
                        {ticket.subject}
                      </h3>
                      <p className="mt-1 text-sm text-slate-600 line-clamp-2">
                        {ticket.description}
                      </p>
                      {ticket.department && (
                        <p className="mt-1 text-xs text-slate-400">
                          Department: {ticket.department}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Feedback for resolved tickets */}
                  {ticket.status === "resolved" && !feedbackMap[ticket.id] && (
                    <div className="mt-4 border-t border-slate-100 pt-4">
                      {fbTicketId === ticket.id ? (
                        <div className="space-y-3">
                          <p className="text-sm font-semibold text-slate-700">
                            How was your experience?
                          </p>
                          <StarRating value={fbRating} onChange={setFbRating} />
                          <textarea
                            value={fbComment}
                            onChange={(e) => setFbComment(e.target.value)}
                            rows={2}
                            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-sky-400"
                            placeholder="Leave a comment (optional)…"
                          />
                          <div className="flex gap-2">
                            <button
                              onClick={submitFeedback}
                              disabled={fbRating === 0}
                              className="rounded-lg bg-sky-500 px-4 py-1.5 text-sm font-bold text-white hover:bg-sky-600 disabled:opacity-50"
                            >
                              Submit Feedback
                            </button>
                            <button
                              onClick={() => setFbTicketId(null)}
                              className="rounded-lg border border-slate-300 px-4 py-1.5 text-sm text-slate-600 hover:bg-slate-50"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button
                          onClick={() => setFbTicketId(ticket.id)}
                          className="text-sm font-semibold text-sky-600 hover:text-sky-700"
                        >
                          ⭐ Leave Feedback
                        </button>
                      )}
                    </div>
                  )}
                  {ticket.status === "resolved" && feedbackMap[ticket.id] && (
                    <div className="mt-3 border-t border-slate-100 pt-3 text-sm text-slate-500">
                      ⭐ Rated {feedbackMap[ticket.id].rating}/5
                      {feedbackMap[ticket.id].comment && (
                        <span className="ml-2">
                          — &quot;{feedbackMap[ticket.id].comment}&quot;
                        </span>
                      )}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   ADMIN DASHBOARD
   ═══════════════════════════════════════════════════════════════ */

function AdminDashboard({
  session,
  onLogout,
}: {
  session: Session;
  onLogout: () => void;
}) {
  const [tab, setTab] = useState<"tickets" | "analytics">("tickets");
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [search, setSearch] = useState("");
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [testingEmail, setTestingEmail] = useState(false);
  const [testEmailResult, setTestEmailResult] = useState<string | null>(null);

  /* ── Email service ── */
  const { emailStatus, emailTicketUpdated } = useEmailService();

  async function handleTestEmail() {
    setTestingEmail(true);
    setTestEmailResult(null);
    if (!EMAIL_READY) {
      const missing = [];
      if (!EJS_SERVICE_ID) missing.push("VITE_EMAILJS_SERVICE_ID");
      if (!EJS_TEMPLATE_ID) missing.push("VITE_EMAILJS_TEMPLATE_ID");
      if (!EJS_PUBLIC_KEY) missing.push("VITE_EMAILJS_PUBLIC_KEY");
      setTestEmailResult(`⚠️ Missing from .env: ${missing.join(", ")}. Follow the setup guide below to get these values.`);
      setTestingEmail(false);
      return;
    }
    const ok = await emailjsSend(ADMIN_EMAIL, "[PRiorix] Test Email", `<div style="font-family:Arial;max-width:500px;margin:0 auto;background:#f8fafc;border-radius:12px;padding:32px;text-align:center"><h2 style="color:#0ea5e9">✅ EmailJS is Working!</h2><p style="color:#475569">This confirms your PRiorix email integration is properly configured.</p><p style="color:#94a3b8;font-size:13px">PRiorix Support System</p></div>`);
    setTestEmailResult(ok ? "✅ Test email sent! Check inbox at " + ADMIN_EMAIL : "❌ EmailJS call failed. Check your Service ID, Template ID, and Public Key in .env");
    setTestingEmail(false);
  }

  useEffect(() => {
    refreshTickets();
  }, []);

  function refreshTickets() {
    const all = getTickets().sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    setTickets(all);
  }

  const filtered = useMemo(() => {
    if (!search.trim()) return tickets;
    const q = search.toLowerCase();
    return tickets.filter(
      (t) =>
        t.subject.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.userEmail.toLowerCase().includes(q) ||
        t.id.includes(q)
    );
  }, [tickets, search]);

  /* Stats */
  const stats = useMemo(() => {
    const total = tickets.length;
    const open = tickets.filter((t) => t.status === "open").length;
    const inProg = tickets.filter((t) => t.status === "in_progress").length;
    const resolved = tickets.filter((t) => t.status === "resolved").length;
    return [
      {
        label: "Total",
        value: total,
        color: "from-slate-500 to-slate-700",
        bg: "bg-slate-50",
      },
      {
        label: "Open",
        value: open,
        color: "from-sky-500 to-sky-600",
        bg: "bg-sky-50",
      },
      {
        label: "In Progress",
        value: inProg,
        color: "from-violet-500 to-violet-600",
        bg: "bg-violet-50",
      },
      {
        label: "Resolved",
        value: resolved,
        color: "from-emerald-500 to-emerald-600",
        bg: "bg-emerald-50",
      },
    ];
  }, [tickets]);

  /* Chart data */
  const priorityData = useMemo(() => {
    const counts: Record<string, number> = { critical: 0, high: 0, medium: 0, low: 0 };
    tickets.forEach((t) => { if (counts[t.priority] !== undefined) counts[t.priority]++; });
    return [
      { name: "Critical", value: counts.critical, color: "#dc2626" },
      { name: "High", value: counts.high, color: "#f43f5e" },
      { name: "Medium", value: counts.medium, color: "#f59e0b" },
      { name: "Low", value: counts.low, color: "#10b981" },
    ].filter((d) => d.value > 0);
  }, [tickets]);

  const dailyData = useMemo(() => {
    const dayMap: Record<string, number> = {};
    tickets.forEach((t) => {
      const day = new Date(t.createdAt).toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
      });
      dayMap[day] = (dayMap[day] || 0) + 1;
    });
    return Object.entries(dayMap)
      .map(([name, count]) => ({ name, count }))
      .slice(-14);
  }, [tickets]);

  async function updateStatus(ticketId: string, newStatus: Ticket["status"]) {
    const all = getTickets();
    const idx = all.findIndex((t) => t.id === ticketId);
    if (idx === -1) return;
    const oldStatus = all[idx].status;
    all[idx].status = newStatus;
    save(LS_TICKETS, all);
    refreshTickets();
    setSelectedTicket({ ...all[idx] });

    sendWebhook({
      event_type: "ticket_updated",
      user_email: all[idx].userEmail,
      ticket_id: ticketId,
      status: newStatus,
    });

    /* 📧 Send status update email to the user */
    const userName = all[idx].userEmail.split("@")[0] || "User";
    emailTicketUpdated(all[idx], userName, oldStatus, newStatus);
  }

  /* ────────── RENDER ────────── */

  return (
    <div className="min-h-screen bg-slate-50">
      <TopNav session={session} onLogout={onLogout} />

      <div className="mx-auto max-w-7xl px-6 py-8">
        {/* Stats */}
        <div className="mb-6 grid grid-cols-2 gap-4 md:grid-cols-4">
          {stats.map((s) => (
            <div
              key={s.label}
              className="card-3d rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition hover:shadow-md"
            >
              <p className="text-xs font-medium text-slate-500">{s.label}</p>
              <p
                className={`text-3xl font-black bg-gradient-to-r ${s.color} bg-clip-text text-transparent`}
              >
                {s.value}
              </p>
            </div>
          ))}
        </div>

        {/* Tabs + Test Email */}
        <div className="mb-6 flex items-center gap-4 flex-wrap">
          <div className="flex gap-1 rounded-xl bg-white p-1 shadow-sm border border-slate-200">
            {(["tickets", "analytics"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`rounded-lg px-5 py-2 text-sm font-semibold transition ${
                  tab === t
                    ? "bg-violet-500 text-white shadow"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                {t === "tickets" ? "🎫 All Tickets" : "📊 Analytics"}
              </button>
            ))}
          </div>
          <button
            onClick={handleTestEmail}
            disabled={testingEmail}
            className="ml-auto rounded-xl border border-violet-200 bg-gradient-to-r from-violet-50 to-purple-50 px-5 py-2.5 text-sm font-semibold text-violet-700 transition hover:from-violet-100 hover:to-purple-100 hover:shadow disabled:opacity-50 flex items-center gap-2"
          >
            {testingEmail ? (
              <>
                <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-violet-300 border-t-violet-600" />
                Sending…
              </>
            ) : (
              <>📧 Test Email Server</>
            )}
          </button>
        </div>

        {/* Test email result banner */}
        {testEmailResult && (
          <div
            className={`mb-4 rounded-xl px-4 py-3 text-sm font-medium ${
              testEmailResult.startsWith("✅")
                ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                : testEmailResult.startsWith("⚠️")
                  ? "bg-amber-50 text-amber-700 border border-amber-200"
                  : "bg-rose-50 text-rose-700 border border-rose-200"
            }`}
          >
            {testEmailResult}
          </div>
        )}

        {/* ── EmailJS Setup Guide (shown when not configured) ── */}
        {!EMAIL_READY && (
          <div className="mb-6 rounded-2xl border-2 border-dashed border-sky-300 bg-gradient-to-br from-sky-50 to-violet-50 p-6">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              📧 Email Setup — 2 Steps Remaining
              <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-semibold text-amber-700">Almost There!</span>
            </h3>
            <p className="mt-1 text-sm text-slate-600">Your Service ID is already configured. Complete these 2 steps to send <strong>real emails</strong>:</p>
            <div className="mt-4 space-y-3">
              {/* Step 1: Service ID - DONE */}
              <div className="flex items-center gap-3 rounded-xl bg-emerald-50 border border-emerald-200 p-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-emerald-500 text-xs font-bold text-white">✓</span>
                <div>
                  <span className="text-sm font-semibold text-emerald-800">Service ID connected</span>
                  <span className="ml-2 rounded bg-emerald-100 px-2 py-0.5 font-mono text-xs text-emerald-700">service_ia1vcld</span>
                </div>
              </div>

              {/* Step 2: Get Public Key */}
              <div className="flex items-start gap-3 rounded-xl bg-white border border-sky-200 p-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-sky-500 text-xs font-bold text-white">1</span>
                <div>
                  <span className="text-sm font-semibold text-slate-800">Get your <span className="text-sky-600">Public Key</span></span>
                  <div className="mt-1 text-xs text-slate-500">
                    → Go to <a href="https://dashboard.emailjs.com/admin/account" target="_blank" rel="noreferrer" className="font-bold text-sky-600 underline">dashboard.emailjs.com/admin/account</a><br/>
                    → Scroll to <strong>API Keys</strong> section → Copy the <strong>Public Key</strong><br/>
                    → Paste it in <code className="rounded bg-slate-100 px-1">.env</code> as <code className="rounded bg-amber-100 px-1 text-amber-800">VITE_EMAILJS_PUBLIC_KEY=your_key_here</code>
                  </div>
                </div>
              </div>

              {/* Step 3: Create Template */}
              <div className="flex items-start gap-3 rounded-xl bg-white border border-violet-200 p-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-violet-500 text-xs font-bold text-white">2</span>
                <div>
                  <span className="text-sm font-semibold text-slate-800">Create an <span className="text-violet-600">Email Template</span></span>
                  <div className="mt-1 text-xs text-slate-500">
                    → Go to <a href="https://dashboard.emailjs.com/templates" target="_blank" rel="noreferrer" className="font-bold text-violet-600 underline">Email Templates tab</a> → Click <strong>Create New Template</strong><br/>
                    → Set these fields exactly:<br/>
                    <div className="mt-1 ml-2 space-y-0.5 font-mono">
                      <div><span className="inline-block w-20 font-sans font-semibold text-slate-600">To Email:</span> <code className="rounded bg-violet-50 px-1 text-violet-700">{"{{to_email}}"}</code></div>
                      <div><span className="inline-block w-20 font-sans font-semibold text-slate-600">Subject:</span> <code className="rounded bg-violet-50 px-1 text-violet-700">{"{{subject}}"}</code></div>
                      <div><span className="inline-block w-20 font-sans font-semibold text-slate-600">Content:</span> <code className="rounded bg-violet-50 px-1 text-violet-700">{"{{{message}}}"}</code> <span className="font-sans text-slate-400">(triple braces for HTML)</span></div>
                    </div>
                    → Copy the <strong>Template ID</strong> (e.g. template_xxx)<br/>
                    → Paste it in <code className="rounded bg-slate-100 px-1">.env</code> as <code className="rounded bg-amber-100 px-1 text-amber-800">VITE_EMAILJS_TEMPLATE_ID=your_template_id</code>
                  </div>
                </div>
              </div>

              {/* Final step */}
              <div className="flex items-center gap-3 rounded-xl bg-amber-50 border border-amber-200 p-3">
                <span className="text-lg">🔄</span>
                <span className="text-sm text-amber-800">After updating <code className="rounded bg-amber-100 px-1">.env</code>, restart the dev server, then click <strong>📧 Test Email Server</strong> above</span>
              </div>
            </div>
          </div>
        )}

        {/* ── Email Activity Log (always visible) ── */}
        {getEmailLog().length > 0 && (
          <div className="mb-6 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <h4 className="text-sm font-bold text-slate-700 mb-2">📬 Email Activity ({getEmailLog().length})</h4>
            <div className="max-h-40 overflow-y-auto space-y-1.5">
              {getEmailLog().slice(0, 15).map((e) => (
                <div key={e.id} className="flex items-center gap-2 rounded-lg bg-slate-50 px-3 py-1.5 text-xs">
                  <span className={`rounded-full px-1.5 py-0.5 text-[10px] font-bold ${e.status === "sent" ? "bg-emerald-100 text-emerald-700" : e.status === "logged" ? "bg-sky-100 text-sky-700" : "bg-amber-100 text-amber-700"}`}>{e.status === "sent" ? "✅ Sent" : e.status === "logged" ? "📋 Logged" : "❌ Failed"}</span>
                  <span className="font-medium text-slate-700">{e.type.replace("_"," ")}</span>
                  <span className="text-slate-400">→</span>
                  <span className="text-slate-600 truncate max-w-[160px]">{e.to}</span>
                  <span className="ml-auto text-slate-400">{new Date(e.timestamp).toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ─── TICKETS TAB ─── */}
        {tab === "tickets" && (
          <div className="space-y-4">
            {/* Search */}
            <div className="relative">
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full max-w-md rounded-xl border border-slate-300 bg-white px-4 py-2.5 pl-10 text-sm outline-none transition focus:border-violet-400 focus:ring-2 focus:ring-violet-100"
                placeholder="Search tickets…"
              />
              <span className="absolute left-3 top-2.5 text-slate-400">
                🔍
              </span>
            </div>

            {filtered.length === 0 ? (
              <div className="card-3d rounded-2xl border border-slate-200 bg-white p-12 text-center shadow-sm">
                <div className="text-5xl mb-3">📭</div>
                <h3 className="text-lg font-bold text-slate-900">
                  No tickets found
                </h3>
                <p className="text-sm text-slate-500">
                  {tickets.length === 0
                    ? "Tickets will appear here when users submit issues."
                    : "Try adjusting your search."}
                </p>
              </div>
            ) : (
              <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-slate-200 bg-slate-50">
                      <tr>
                        <th className="px-4 py-3 text-left font-semibold text-slate-600">
                          Ticket
                        </th>
                        <th className="px-4 py-3 text-left font-semibold text-slate-600">
                          User
                        </th>
                        <th className="px-4 py-3 text-left font-semibold text-slate-600">
                          Priority
                        </th>
                        <th className="px-4 py-3 text-left font-semibold text-slate-600">
                          Status
                        </th>
                        <th className="px-4 py-3 text-left font-semibold text-slate-600">
                          Dept
                        </th>
                        <th className="px-4 py-3 text-left font-semibold text-slate-600">
                          Created
                        </th>
                        <th className="px-4 py-3 text-left font-semibold text-slate-600">
                          Action
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filtered.map((t) => (
                        <tr
                          key={t.id}
                          className="transition hover:bg-slate-50"
                        >
                          <td className="px-4 py-3">
                            <div className="font-semibold text-slate-900">
                              {t.subject}
                            </div>
                            <div className="text-xs text-slate-500 line-clamp-2">
                              {t.description}
                            </div>
                          </td>
                          <td className="px-4 py-3 text-slate-600">
                            {t.userEmail}
                          </td>
                          <td className="px-4 py-3">
                            <span
                              className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs font-semibold ${priorityBadge(
                                t.priority
                              )}`}
                            >
                              <span
                                className={`h-1.5 w-1.5 rounded-full ${priorityDot(
                                  t.priority
                                )}`}
                              />
                              {t.priority.toUpperCase()}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <span
                              className={`rounded-full border px-2 py-0.5 text-xs font-semibold ${statusBadge(
                                t.status
                              )}`}
                            >
                              {t.status.replace("_", " ").toUpperCase()}
                            </span>
                          </td>
                          <td className="px-4 py-3 capitalize text-slate-600">
                            {t.department}
                          </td>
                          <td className="px-4 py-3 text-slate-500">
                            {new Date(t.createdAt).toLocaleDateString()}
                          </td>
                          <td className="px-4 py-3">
                            <button
                              onClick={() => setSelectedTicket(t)}
                              className="rounded-lg bg-violet-50 px-3 py-1 text-xs font-semibold text-violet-600 transition hover:bg-violet-100"
                            >
                              View
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ─── ANALYTICS TAB ─── */}
        {tab === "analytics" && (
          <div className="grid gap-6 md:grid-cols-2">
            {/* Priority Pie */}
            <div className="card-3d rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
              <h3 className="mb-4 text-lg font-bold text-slate-900">
                Priority Distribution
              </h3>
              {priorityData.length === 0 ? (
                <p className="text-sm text-slate-500">No data yet.</p>
              ) : (
                <ResponsiveContainer width="100%" height={280}>
                  <PieChart>
                    <Pie
                      data={priorityData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      innerRadius={50}
                      strokeWidth={2}
                      stroke="#fff"
                    >
                      {priorityData.map((d, i) => (
                        <Cell key={i} fill={d.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              )}
              <div className="mt-2 flex justify-center gap-4">
                {priorityData.map((d) => (
                  <span
                    key={d.name}
                    className="flex items-center gap-1 text-xs text-slate-600"
                  >
                    <span
                      className="inline-block h-3 w-3 rounded-full"
                      style={{ background: d.color }}
                    />
                    {d.name} ({d.value})
                  </span>
                ))}
              </div>
            </div>

            {/* Daily Bar */}
            <div className="card-3d rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
              <h3 className="mb-4 text-lg font-bold text-slate-900">
                Tickets per Day
              </h3>
              {dailyData.length === 0 ? (
                <p className="text-sm text-slate-500">No data yet.</p>
              ) : (
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={dailyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Bar dataKey="count" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>
        )}
      </div>

      {/* ─── TICKET DETAIL MODAL ─── */}
      {selectedTicket && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4"
          onClick={() => setSelectedTicket(null)}
        >
          <div
            className="w-full max-w-lg rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900">
                Ticket Details
              </h3>
              <button
                onClick={() => setSelectedTicket(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-sm max-h-[75vh] overflow-y-auto pr-1">
              <div>
                <span className="font-semibold text-slate-700">Subject:</span>{" "}
                {selectedTicket.subject}
              </div>
              <div>
                <span className="font-semibold text-slate-700">
                  Description:
                </span>
                <p className="mt-1 rounded-lg bg-slate-50 p-3 text-slate-600">
                  {selectedTicket.description}
                </p>
              </div>

              {/* ─── v3.0 Classification Header ─── */}
              <div className="rounded-lg border border-slate-200 bg-gradient-to-r from-slate-50 to-violet-50 p-3">
                <div className="mb-2 flex items-center justify-between">
                  <div className="text-xs font-bold text-violet-600 uppercase tracking-wide">v3.0 Decision Engine Classification</div>
                  <div className="flex gap-1.5">
                    {selectedTicket.validationPassed && (
                      <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-700">✓ Validated</span>
                    )}
                    {selectedTicket.financialIssue && (
                      <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-bold text-amber-700">💰 Financial</span>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-xs text-slate-400">Priority</span>
                    <div className="flex items-center gap-2">
                      <span className={`inline-block rounded-full border px-2.5 py-0.5 text-xs font-bold ${priorityBadge(selectedTicket.priority)}`}>
                        {selectedTicket.priority.toUpperCase()}
                      </span>
                      <span className="text-xs text-slate-400">Score: {selectedTicket.priorityScore || "—"}</span>
                    </div>
                  </div>
                  <div>
                    <span className="text-xs text-slate-400">Department</span>
                    <div className="font-semibold text-slate-700">{selectedTicket.department}</div>
                    {selectedTicket.secondaryDepartment && (
                      <div className="text-[10px] text-slate-400">Secondary: {selectedTicket.secondaryDepartment}</div>
                    )}
                  </div>
                  <div>
                    <span className="text-xs text-slate-400">Category</span>
                    <div className="font-semibold text-slate-700">{selectedTicket.category || "General"}</div>
                  </div>
                  <div>
                    <span className="text-xs text-slate-400">Sub-Category</span>
                    <div className="font-semibold text-slate-700">{selectedTicket.subCategory || "—"}</div>
                  </div>
                </div>
              </div>

              {/* ─── Impact × Urgency + Modifiers ─── */}
              <div className="rounded-lg border border-slate-200 bg-white p-3">
                <div className="mb-2 text-xs font-bold text-slate-500 uppercase tracking-wide">Impact × Urgency + Modifiers</div>
                <div className="grid grid-cols-5 gap-1 text-center text-xs">
                  <div className={`rounded-lg p-2 ${selectedTicket.impact === "high" ? "bg-rose-100 text-rose-700 font-bold" : selectedTicket.impact === "medium" ? "bg-amber-50 text-amber-600" : "bg-slate-50 text-slate-500"}`}>
                    <div className="text-lg">{selectedTicket.impactScore || "—"}</div><div>Impact</div>
                  </div>
                  <div className="text-lg font-bold text-slate-300 flex items-center justify-center">×</div>
                  <div className={`rounded-lg p-2 ${selectedTicket.urgency === "high" ? "bg-amber-100 text-amber-700 font-bold" : selectedTicket.urgency === "medium" ? "bg-amber-50 text-amber-600" : "bg-slate-50 text-slate-500"}`}>
                    <div className="text-lg">{selectedTicket.urgencyScore || "—"}</div><div>Urgency</div>
                  </div>
                  <div className="text-lg font-bold text-slate-300 flex items-center justify-center">+</div>
                  <div className="rounded-lg bg-violet-50 p-2 text-violet-700 font-bold">
                    <div className="text-lg">{selectedTicket.priorityModifiers?.length || 0}</div><div>Mods</div>
                  </div>
                </div>
                {selectedTicket.priorityModifiers && selectedTicket.priorityModifiers.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {selectedTicket.priorityModifiers.map((m, i) => (
                      <span key={i} className="rounded-full bg-violet-100 px-2 py-0.5 text-[10px] font-semibold text-violet-700">{m}</span>
                    ))}
                  </div>
                )}
                <div className="mt-2 text-center text-xs text-slate-500">
                  Final Score: {selectedTicket.priorityScore || ((selectedTicket.impactScore || 2) * (selectedTicket.urgencyScore || 2))} → <span className="font-bold">{selectedTicket.priority.toUpperCase()}</span>
                </div>
              </div>

              {/* ─── Decision Pipeline ─── */}
              {selectedTicket.decisionPipeline && selectedTicket.decisionPipeline.length > 0 && (
                <div className="rounded-lg border border-slate-200 bg-white p-2">
                  <div className="text-xs font-bold text-slate-500 mb-1.5">Decision Pipeline</div>
                  <div className="flex flex-wrap gap-1">
                    {selectedTicket.decisionPipeline.map((step, i) => (
                      <span key={i} className="flex items-center gap-1 text-[10px]">
                        <span className="rounded-full bg-slate-100 px-1.5 py-0.5 font-medium text-slate-600">{step}</span>
                        {i < selectedTicket.decisionPipeline.length - 1 && <span className="text-slate-300">→</span>}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* ─── SLA + Sentiment + Confidence ─── */}
              <div className="grid grid-cols-3 gap-2">
                <div className="rounded-lg bg-sky-50 border border-sky-200 p-2 text-center">
                  <div className="text-xs text-sky-500">SLA Response</div>
                  <div className="text-xs font-bold text-sky-700">{selectedTicket.slaResponseTime || "1h"}</div>
                </div>
                <div className="rounded-lg bg-violet-50 border border-violet-200 p-2 text-center">
                  <div className="text-xs text-violet-500">SLA Resolution</div>
                  <div className="text-xs font-bold text-violet-700">{selectedTicket.slaResolutionTime || "24h"}</div>
                </div>
                <div className="rounded-lg bg-amber-50 border border-amber-200 p-2 text-center">
                  <div className="text-xs text-amber-500">Sentiment</div>
                  <div className="text-xs font-bold text-amber-700 capitalize">
                    {selectedTicket.sentiment === "angry" ? "😠" : selectedTicket.sentiment === "satisfied" ? "😊" : "😐"} {selectedTicket.sentiment || "neutral"}
                  </div>
                </div>
              </div>

              {/* Confidence Bar */}
              <div className="rounded-lg bg-white border border-slate-200 p-2">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-slate-500">AI Confidence</span>
                  <span className="font-bold">{selectedTicket.confidenceScore || 70}%</span>
                </div>
                <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                  <div className={`h-full rounded-full ${(selectedTicket.confidenceScore || 70) >= 80 ? "bg-emerald-500" : (selectedTicket.confidenceScore || 70) >= 50 ? "bg-amber-500" : "bg-rose-500"}`} style={{ width: `${selectedTicket.confidenceScore || 70}%` }} />
                </div>
              </div>

              {/* Standard fields */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="font-semibold text-slate-700">User:</span>{" "}
                  <span className="text-slate-600">{selectedTicket.userEmail}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-700">Deadline:</span>{" "}
                  <span className="text-slate-600">{new Date(selectedTicket.deadline).toLocaleDateString()}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-700">Spam:</span>{" "}
                  {selectedTicket.isSpam ? "⚠️ Yes" : "✅ No"}
                </div>
                <div>
                  <span className="font-semibold text-slate-700">Created:</span>{" "}
                  <span className="text-slate-600">{new Date(selectedTicket.createdAt).toLocaleDateString()}</span>
                </div>
              </div>

              {selectedTicket.aiSuggestion && (
                <div>
                  <span className="font-semibold text-slate-700">
                    🤖 AI Agent Suggestion:
                  </span>
                  <div className="mt-1 rounded-lg border border-violet-200 bg-violet-50 p-3 text-xs text-violet-800 whitespace-pre-wrap">
                    {selectedTicket.aiSuggestion}
                  </div>
                </div>
              )}

              <div>
                <span className="font-semibold text-slate-700">
                  Update Status:
                </span>
                <div className="mt-2 flex gap-2">
                  {(
                    ["open", "in_progress", "resolved", "spam"] as const
                  ).map((s) => (
                    <button
                      key={s}
                      onClick={() => updateStatus(selectedTicket.id, s)}
                      className={`rounded-lg border px-3 py-1.5 text-xs font-semibold transition ${
                        selectedTicket.status === s
                          ? statusBadge(s) + " ring-2 ring-offset-1 ring-slate-300"
                          : "border-slate-200 text-slate-600 hover:bg-slate-50"
                      }`}
                    >
                      {s.replace("_", " ").toUpperCase()}
                    </button>
                  ))}
                </div>
                {/* Email status indicator */}
                {emailStatus.lastType === "ticket_updated" && (
                  <div className={`mt-3 rounded-lg px-3 py-2 text-xs font-medium ${
                    emailStatus.sending
                      ? "bg-sky-50 text-sky-700"
                      : emailStatus.lastResult === "success"
                        ? "bg-emerald-50 text-emerald-700"
                        : emailStatus.lastResult === "not_configured"
                          ? "bg-sky-50 text-sky-700"
                          : "bg-amber-50 text-amber-700"
                  }`}>
                    {emailStatus.sending ? "📧 Sending notification email…" : emailStatus.lastMessage}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   MAIN APP
   ═══════════════════════════════════════════════════════════════ */

export default function App() {
  const [page, setPage] = useState<Page>("landing");
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    // Seed admin account
    seedAdmin();
    // Restore session
    const s = getSession();
    if (s) {
      setSession(s);
      setPage(s.role === "admin" ? "admin-dashboard" : "user-dashboard");
    }
    setReady(true);
  }, []);

  function handleAuth(s: Session) {
    setSession(s);
    setPage(s.role === "admin" ? "admin-dashboard" : "user-dashboard");
  }

  function handleLogout() {
    localStorage.removeItem(LS_SESSION);
    setSession(null);
    setPage("landing");
  }

  if (!ready) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-white">
        <div className="flex flex-col items-center gap-3">
          <img
            src="/logo.png"
            alt="PRiorix"
            className="h-12 w-12 animate-pulse rounded-xl"
          />
          <span className="text-sm font-semibold text-slate-500">
            Loading PRiorix…
          </span>
        </div>
      </div>
    );
  }

  switch (page) {
    case "landing":
      return <LandingPage onNavigate={setPage} />;
    case "login":
      return (
        <LoginPage
          onNavigate={setPage}
          onAuth={handleAuth}
        />
      );
    case "signup":
      return (
        <SignupPage
          onNavigate={setPage}
          onAuth={handleAuth}
        />
      );
    case "user-dashboard":
      return session ? (
        <UserDashboard session={session} onLogout={handleLogout} />
      ) : (
        <LandingPage onNavigate={setPage} />
      );
    case "admin-dashboard":
      return session ? (
        <AdminDashboard session={session} onLogout={handleLogout} />
      ) : (
        <LandingPage onNavigate={setPage} />
      );
    default:
      return <LandingPage onNavigate={setPage} />;
  }
}
