import cors from "cors";
import express from "express";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { execSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import bcrypt from "bcryptjs";
import OpenAI from "openai";
import { PrismaClient } from "@prisma/client";
import { z } from "zod";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

if (!process.env.DATABASE_URL) {
  process.env.DATABASE_URL = "file:./prisma/dev.db";
}

const app = express();
const port = Number(process.env.PORT || 8787);

app.use(cors());
app.use(express.json({ limit: "5mb" }));

ensurePrismaReady();

const prisma = new PrismaClient();
const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

const priorityMap = {
  high: "HIGH",
  medium: "MEDIUM",
  low: "LOW",
};

const statusMap = {
  open: "OPEN",
  spam: "SPAM",
  in_progress: "IN_PROGRESS",
  resolved: "RESOLVED",
};

function runSafeCommand(command) {
  execSync(command, {
    cwd: __dirname,
    stdio: "inherit",
    env: process.env,
  });
}

function ensurePrismaReady() {
  try {
    runSafeCommand("npx prisma migrate dev --name init --skip-generate");
  } catch (error) {
    console.warn("Prisma migrate dev failed, falling back to db push.");
    runSafeCommand("npx prisma db push --skip-generate");
  }

  runSafeCommand("npx prisma generate");
}

function generateToken() {
  return crypto.randomBytes(32).toString("hex");
}

async function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Authentication required." });
  }

  const token = authHeader.split(" ")[1];
  const user = await prisma.user.findUnique({ where: { token } });

  if (!user) {
    return res.status(401).json({ error: "Invalid or expired token." });
  }

  req.user = { id: user.id, name: user.name, email: user.email, role: user.role };
  next();
}

async function postWebhook(payload) {
  if (!process.env.N8N_WEBHOOK_URL) {
    return;
  }

  try {
    await fetch(process.env.N8N_WEBHOOK_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  } catch (error) {
    console.error("Webhook dispatch failed", error);
  }
}

async function getAiText(messages) {
  if (!openai) {
    throw new Error("OPENAI_API_KEY is missing.");
  }

  const response = await openai.responses.create({
    model: "gpt-4.1-mini",
    input: messages,
    temperature: 0.2,
  });

  return (response.output_text || "").trim();
}

function parseJsonObject(rawText) {
  const trimmed = rawText.trim();

  try {
    return JSON.parse(trimmed);
  } catch (_err) {
    const match = trimmed.match(/\{[\s\S]*\}/);
    if (!match) {
      throw new Error("Unable to find JSON object in model response.");
    }
    return JSON.parse(match[0]);
  }
}

// ─── Auth Routes ──────────────────────────────────────────────

app.post("/api/auth/signup", async (req, res) => {
  const schema = z.object({
    name: z.string().min(2),
    email: z.string().email(),
    password: z.string().min(6),
    role: z.enum(["USER", "ADMIN"]).default("USER"),
  });

  try {
    const parsed = schema.parse(req.body);

    const existing = await prisma.user.findUnique({ where: { email: parsed.email } });
    if (existing) {
      return res.status(409).json({ error: "An account with this email already exists." });
    }

    const passwordHash = await bcrypt.hash(parsed.password, 10);
    const token = generateToken();

    const user = await prisma.user.create({
      data: {
        name: parsed.name,
        email: parsed.email,
        passwordHash,
        role: parsed.role,
        token,
      },
    });

    res.json({
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
      token,
    });
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: error.message || "Signup failed." });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const schema = z.object({
    email: z.string().email(),
    password: z.string().min(1),
  });

  try {
    const parsed = schema.parse(req.body);

    const user = await prisma.user.findUnique({ where: { email: parsed.email } });
    if (!user) {
      return res.status(401).json({ error: "Invalid email or password." });
    }

    const valid = await bcrypt.compare(parsed.password, user.passwordHash);
    if (!valid) {
      return res.status(401).json({ error: "Invalid email or password." });
    }

    const token = generateToken();
    await prisma.user.update({ where: { id: user.id }, data: { token } });

    res.json({
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
      token,
    });
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: error.message || "Login failed." });
  }
});

app.get("/api/auth/me", authMiddleware, async (req, res) => {
  res.json({ user: req.user });
});

app.post("/api/auth/logout", authMiddleware, async (req, res) => {
  await prisma.user.update({ where: { id: req.user.id }, data: { token: null } });
  res.json({ ok: true });
});

// ─── Health ───────────────────────────────────────────────────

app.get("/api/health", async (_req, res) => {
  const tickets = await prisma.ticket.count();
  const users = await prisma.user.count();
  res.json({ ok: true, tickets, users });
});

// ─── AI Chat ──────────────────────────────────────────────────

app.post("/api/ai/chat", async (req, res) => {
  const schema = z.object({
    subject: z.string().min(2),
    description: z.string().min(5),
    history: z
      .array(
        z.object({
          role: z.enum(["user", "assistant"]),
          content: z.string().min(1),
        })
      )
      .default([]),
  });

  try {
    const parsed = schema.parse(req.body);
    const basePrompt = `You are PRiorix. Analyze this issue: ${parsed.subject} ${parsed.description}. If you need more info to understand the problem or department, ask short questions. If you have enough info, output EXACTLY: SOLUTION: <your solution here>.`;

    const messages = [
      {
        role: "system",
        content:
          "You are a support triage assistant. Keep questions brief and ask only one at a time.",
      },
      { role: "user", content: basePrompt },
      ...parsed.history,
    ];

    const text = await getAiText(messages);
    res.json({ message: text, isSolution: text.startsWith("SOLUTION:") });
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: error.message || "Failed to generate AI response" });
  }
});

// ─── Interactions ─────────────────────────────────────────────

app.post("/api/interactions/solved", async (req, res) => {
  const schema = z.object({
    userEmail: z.string().email(),
    subject: z.string().min(2),
  });

  try {
    const parsed = schema.parse(req.body);
    console.info(`Resolved via AI for ${parsed.userEmail}: ${parsed.subject}`);
    res.json({ ok: true });
  } catch (error) {
    res.status(400).json({ error: error.message || "Invalid payload" });
  }
});

// ─── Tickets ──────────────────────────────────────────────────

app.post("/api/tickets/escalate", async (req, res) => {
  const schema = z.object({
    userEmail: z.string().email(),
    subject: z.string().min(2),
    description: z.string().min(5),
    attachments: z.string().optional().nullable(),
    transcript: z.array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string(),
      })
    ),
  });

  try {
    const parsed = schema.parse(req.body);

    const triagePrompt = `Return JSON: { "is_spam": boolean, "is_contextual_spam": boolean, "priority": "high/medium/low", "department": "tech/billing/general", "deadline_hours": integer, "agent_suggestion": "detailed fix" }`;

    const aiText = await getAiText([
      {
        role: "system",
        content:
          "Classify the ticket and return only valid JSON with all fields required.",
      },
      {
        role: "user",
        content: `${triagePrompt}\nIssue subject: ${parsed.subject}\nIssue description: ${parsed.description}\nTranscript: ${JSON.stringify(parsed.transcript)}`,
      },
    ]);

    const json = parseJsonObject(aiText);
    const isSpam = Boolean(json.is_spam || json.is_contextual_spam);
    const priority = priorityMap[String(json.priority || "medium").toLowerCase()] || "MEDIUM";
    const department = ["tech", "billing", "general"].includes(String(json.department))
      ? String(json.department)
      : "general";
    const deadlineHours = Number.isFinite(Number(json.deadline_hours))
      ? Number(json.deadline_hours)
      : 72;

    const ticket = await prisma.ticket.create({
      data: {
        userEmail: parsed.userEmail,
        subject: parsed.subject,
        description: parsed.description,
        attachments: parsed.attachments || null,
        isSpam,
        priority,
        department,
        aiSuggestion: String(json.agent_suggestion || "Review required."),
        deadline: new Date(Date.now() + deadlineHours * 60 * 60 * 1000),
        status: isSpam ? "SPAM" : "OPEN",
      },
    });

    await postWebhook({
      event_type: "ticket_created",
      user_email: ticket.userEmail,
      ticket_id: String(ticket.id),
      is_spam: ticket.isSpam,
      priority: ticket.priority.toLowerCase(),
    });

    res.json(ticket);
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: error.message || "Failed to escalate ticket" });
  }
});

app.get("/api/tickets", async (_req, res) => {
  const tickets = await prisma.ticket.findMany({
    orderBy: { createdAt: "desc" },
    include: { feedback: true },
  });
  res.json(tickets);
});

app.get("/api/tickets/user", async (req, res) => {
  const email = String(req.query.email || "");
  if (!email) {
    return res.status(400).json({ error: "Email query parameter is required." });
  }

  const tickets = await prisma.ticket.findMany({
    where: { userEmail: email },
    orderBy: { createdAt: "desc" },
    include: { feedback: true },
  });

  return res.json(tickets);
});

app.patch("/api/tickets/:id/status", async (req, res) => {
  const schema = z.object({ status: z.enum(["open", "spam", "in_progress", "resolved"]) });

  try {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) {
      return res.status(400).json({ error: "Invalid id" });
    }

    const parsed = schema.parse(req.body);
    const status = statusMap[parsed.status];

    const ticket = await prisma.ticket.update({ where: { id }, data: { status } });

    await postWebhook({
      event_type: "ticket_updated",
      user_email: ticket.userEmail,
      ticket_id: String(ticket.id),
      status: parsed.status,
    });

    return res.json(ticket);
  } catch (error) {
    return res.status(400).json({ error: error.message || "Failed to update status" });
  }
});

app.post("/api/feedback", async (req, res) => {
  const schema = z.object({
    ticketId: z.number().int(),
    rating: z.number().int().min(1).max(5),
    comment: z.string().optional().nullable(),
  });

  try {
    const parsed = schema.parse(req.body);
    const feedback = await prisma.feedback.create({
      data: {
        ticketId: parsed.ticketId,
        rating: parsed.rating,
        comment: parsed.comment || null,
      },
    });
    res.json(feedback);
  } catch (error) {
    res.status(400).json({ error: error.message || "Failed to save feedback" });
  }
});

// ─── Serve Frontend ───────────────────────────────────────────

const distPath = path.join(__dirname, "dist");
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get("*", (_req, res) => {
    res.sendFile(path.join(distPath, "index.html"));
  });
}

app.listen(port, () => {
  console.log(`PRiorix server running on port ${port}`);
});
