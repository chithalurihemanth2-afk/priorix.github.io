# 🎫 PRiorix — AI-Powered Support Ticket System

## Quick Start

```bash
npm install
npm run dev
```

Open **http://localhost:5173** and you're live!

### Admin Login (pre-seeded)
- **Email:** `chithalurihemanth972@gmail.com`
- **Password:** `Hemu@2007`

---

## 📧 Email Setup (EmailJS — Free, Browser-Based)

PRiorix sends real emails directly from the browser using **EmailJS** — no server needed!

### One-Time Setup (5 minutes)

#### Step 1: Create EmailJS Account
1. Go to **https://www.emailjs.com** → **Sign Up Free**
2. Confirm your email address

#### Step 2: Add Gmail Service
1. Go to **Email Services** → **Add New Service**
2. Select **Gmail**
3. Click **Connect Account** → authorize `chithalurihemanth972@gmail.com`
4. Copy the **Service ID** (e.g., `service_abc123`)

#### Step 3: Create Email Template
1. Go to **Email Templates** → **Create New Template**
2. Set these fields:
   - **To Email:** `{{to_email}}`
   - **Subject:** `{{subject}}`
   - **Content:** `{{{message}}}` (must use triple braces for HTML)
3. Save and copy the **Template ID** (e.g., `template_xyz789`)

#### Step 4: Get Public Key
1. Go to **Account** → **API Keys**
2. Copy the **Public Key** (e.g., `aBcDeFgHiJkLmN`)

#### Step 5: Configure .env
Add these to your `.env` file:
```env
VITE_EMAILJS_SERVICE_ID=service_abc123
VITE_EMAILJS_TEMPLATE_ID=template_xyz789
VITE_EMAILJS_PUBLIC_KEY=aBcDeFgHiJkLmN
```

#### Step 6: Restart & Test
1. Restart the dev server: `npm run dev`
2. Login as Admin
3. Click **📧 Test Email Server** button
4. Check your inbox at `chithalurihemanth972@gmail.com`

---

## 📧 Email Automation Triggers

| Event | Recipient | When |
|-------|-----------|------|
| **Ticket Created** | 📬 User's email | User submits ticket (after AI chat) |
| **High Priority Alert** | 🚨 Admin email | Ticket priority is HIGH |
| **Status Updated** | 📬 User's email | Admin changes ticket status |

All emails include beautiful branded HTML with ticket details.

---

## 🔧 Optional: AI Features (OpenAI)

To enable real AI chat and triage, add your OpenAI key to `.env`:
```env
VITE_OPENAI_API_KEY=sk-...
```

Without this key, PRiorix uses intelligent mock AI responses (still fully functional for demo).

---

## 🔧 Optional: Webhook Integration (n8n)

To connect with n8n workflows:
```env
VITE_N8N_WEBHOOK_URL=https://your-n8n-instance.com/webhook/xxx
```

---

## 🔧 Optional: Python Email Server (Alternative)

If you prefer running a local Python server instead of EmailJS:

```bash
pip install -r requirements.txt
python email_server.py
```

This starts an email server at `http://localhost:5100` that sends emails via SMTP (Gmail).

---

## Features

- 🔐 **Login & Signup** — Users sign up, admin is pre-seeded
- 🤖 **AI Chat** — OpenAI-powered issue analysis with iterative Q&A
- 🎫 **Ticket System** — Auto-classified by priority, department, deadline
- 📊 **Admin Dashboard** — Ticket management + analytics (Recharts)
- 📧 **Email Automation** — Real-time email notifications (EmailJS)
- ⭐ **User Feedback** — Star rating + comments on resolved tickets
- 🔔 **Spam Detection** — AI-powered spam identification
- 🎨 **Modern UI** — Tailwind CSS with 3D hover effects
