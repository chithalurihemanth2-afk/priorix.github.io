"""
PRiorix Email Automation Server
================================
A Python FastAPI microservice that handles all email notifications via SMTP.

Run it:  python email_server.py
Default: http://localhost:5100

Environment variables (set in .env or export):
  SMTP_EMAIL         – sender Gmail address
  SMTP_APP_PASSWORD  – Gmail App Password (not your regular password)
  ADMIN_EMAIL        – admin email for high-priority alerts
  SMTP_PORT          – SMTP port (default 587)
  SMTP_SERVER        – SMTP server (default smtp.gmail.com)
"""

import os
import sys
import json
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime
from typing import Optional

# ── Load .env file ──────────────────────────────────────────────
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    # Fallback: manually parse .env
    env_path = os.path.join(os.path.dirname(__file__), ".env")
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, val = line.partition("=")
                    os.environ.setdefault(key.strip(), val.strip().strip('"').strip("'"))

# ── Config ──────────────────────────────────────────────────────
SMTP_EMAIL = os.getenv("SMTP_EMAIL", "").strip()
SMTP_APP_PASSWORD = os.getenv("SMTP_APP_PASSWORD", "").strip()
ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "chithalurihemanth972@gmail.com").strip()
SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com").strip()
SMTP_PORT = int(os.getenv("SMTP_PORT", "587").strip())
SERVER_PORT = int(os.getenv("EMAIL_SERVER_PORT", "5100").strip())

# ── FastAPI ─────────────────────────────────────────────────────
try:
    from fastapi import FastAPI, HTTPException
    from fastapi.middleware.cors import CORSMiddleware
    from pydantic import BaseModel, EmailStr
except ImportError:
    print("❌ Missing dependencies. Run:  pip install fastapi uvicorn pydantic[email] python-dotenv")
    sys.exit(1)

app = FastAPI(title="PRiorix Email Server", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Models ──────────────────────────────────────────────────────
class TicketCreatedPayload(BaseModel):
    to_email: str
    user_name: str = "User"
    ticket_id: str
    subject: str
    priority: str
    department: str
    deadline: str

class TicketUpdatedPayload(BaseModel):
    to_email: str
    user_name: str = "User"
    ticket_id: str
    subject: str
    old_status: str = ""
    new_status: str
    message: str = ""

class AdminAlertPayload(BaseModel):
    ticket_id: str
    subject: str
    description: str = ""
    priority: str
    department: str
    user_email: str
    deadline: str = ""
    ai_suggestion: str = ""


# ── Email Templates ─────────────────────────────────────────────

def _base_html(body_content: str, preview: str = "PRiorix Notification") -> str:
    """Base HTML email wrapper with PRiorix branding."""
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PRiorix</title>
</head>
<body style="margin:0;padding:0;background:#f8fafc;font-family:'Segoe UI',system-ui,-apple-system,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;padding:32px 0;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);">

  <!-- Header -->
  <tr>
    <td style="background:linear-gradient(135deg,#6366f1 0%,#8b5cf6 50%,#a855f7 100%);padding:32px 40px;">
      <h1 style="margin:0;color:#ffffff;font-size:24px;font-weight:800;letter-spacing:-0.5px;">
        🎫 PRiorix
      </h1>
      <p style="margin:6px 0 0;color:rgba(255,255,255,0.85);font-size:14px;">
        {preview}
      </p>
    </td>
  </tr>

  <!-- Body -->
  <tr>
    <td style="padding:32px 40px;color:#1e293b;font-size:15px;line-height:1.7;">
      {body_content}
    </td>
  </tr>

  <!-- Footer -->
  <tr>
    <td style="padding:20px 40px;background:#f8fafc;border-top:1px solid #e2e8f0;text-align:center;">
      <p style="margin:0;font-size:12px;color:#94a3b8;">
        This is an automated message from <strong style="color:#6366f1;">PRiorix</strong> Support System.<br>
        Sent at {datetime.now().strftime("%B %d, %Y at %I:%M %P")} IST
      </p>
    </td>
  </tr>

</table>
</td></tr>
</table>
</body>
</html>"""


def ticket_created_html(d: TicketCreatedPayload) -> str:
    body = f"""
    <p style="margin:0 0 16px;">Hi <strong>{d.user_name}</strong>,</p>
    <p style="margin:0 0 24px;">
      Your support ticket has been created successfully! Here are the details:
    </p>

    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border-radius:12px;padding:20px;margin-bottom:24px;">
      <tr><td style="padding:8px 16px;"><span style="color:#64748b;font-size:13px;">Ticket ID</span><br>
        <strong style="font-size:16px;font-family:monospace;color:#6366f1;">{d.ticket_id}</strong></td></tr>
      <tr><td style="padding:8px 16px;"><span style="color:#64748b;font-size:13px;">Subject</span><br>
        <strong>{d.subject}</strong></td></tr>
      <tr><td style="padding:8px 16px;"><span style="color:#64748b;font-size:13px;">Priority</span><br>
        <strong style="color:{"#ef4444" if d.priority=="high" else "#f59e0b" if d.priority=="medium" else "#10b981"};">
          {'🔴' if d.priority=='high' else '🟡' if d.priority=='medium' else '🟢'} {d.priority.upper()}
        </strong></td></tr>
      <tr><td style="padding:8px 16px;"><span style="color:#64748b;font-size:13px;">Department</span><br>
        <strong>{d.department.title()}</strong></td></tr>
      <tr><td style="padding:8px 16px;"><span style="color:#64748b;font-size:13px;">Deadline</span><br>
        <strong>{d.deadline}</strong></td></tr>
    </table>

    <p style="margin:0 0 8px;">Please save your <strong>Ticket ID</strong> for future reference. You can track your ticket status anytime from your PRiorix dashboard.</p>

    <div style="background:#ede9fe;border-left:4px solid #7c3aed;border-radius:8px;padding:16px;margin-top:20px;">
      <p style="margin:0;font-size:14px;color:#5b21b6;">
        💡 <strong>Tip:</strong> You'll receive email updates whenever your ticket status changes.
      </p>
    </div>
    """
    return _base_html(body, "Your Ticket Has Been Created")


def ticket_updated_html(d: TicketUpdatedPayload) -> str:
    status_colors = {
        "open": "#3b82f6", "in_progress": "#8b5cf6",
        "resolved": "#10b981", "spam": "#ef4444"
    }
    new_color = status_colors.get(d.new_status, "#64748b")

    body = f"""
    <p style="margin:0 0 16px;">Hi <strong>{d.user_name}</strong>,</p>
    <p style="margin:0 0 24px;">
      Your support ticket has been updated:
    </p>

    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border-radius:12px;padding:20px;margin-bottom:24px;">
      <tr><td style="padding:8px 16px;"><span style="color:#64748b;font-size:13px;">Ticket ID</span><br>
        <strong style="font-family:monospace;color:#6366f1;">{d.ticket_id}</strong></td></tr>
      <tr><td style="padding:8px 16px;"><span style="color:#64748b;font-size:13px;">Subject</span><br>
        <strong>{d.subject}</strong></td></tr>
      <tr><td style="padding:8px 16px;">
        <span style="color:#64748b;font-size:13px;">New Status</span><br>
        <strong style="color:{new_color};font-size:16px;">
          {'🔵' if d.new_status=='open' else '🟣' if d.new_status=='in_progress' else '🟢' if d.new_status=='resolved' else '🔴'} {d.new_status.replace('_',' ').upper()}
        </strong>
      </td></tr>
    </table>

    {"<p style='margin:0 0 12px;'>📝 <strong>Admin note:</strong> " + d.message + "</p>" if d.message else ""}

    <div style="background:#ede9fe;border-left:4px solid #7c3aed;border-radius:8px;padding:16px;margin-top:20px;">
      <p style="margin:0;font-size:14px;color:#5b21b6;">
        {'✅ <strong>Great news!</strong> Your issue has been resolved. Please visit your dashboard to leave feedback.' if d.new_status=='resolved' else '🔄 Our team is working on your issue. We\'ll keep you updated.'}
      </p>
    </div>
    """
    return _base_html(body, f"Ticket Update: {d.new_status.replace('_',' ').title()}")


def admin_alert_html(d: AdminAlertPayload) -> str:
    body = f"""
    <p style="margin:0 0 16px;">🚨 <strong>High Priority Ticket Alert</strong></p>
    <p style="margin:0 0 24px;">
      A new <span style="color:#ef4444;font-weight:bold;">HIGH PRIORITY</span> ticket has been created and requires immediate attention.
    </p>

    <table width="100%" cellpadding="0" cellspacing="0" style="background:#fef2f2;border:1px solid #fecaca;border-radius:12px;padding:20px;margin-bottom:24px;">
      <tr><td style="padding:8px 16px;"><span style="color:#991b1b;font-size:13px;">Ticket ID</span><br>
        <strong style="font-family:monospace;color:#dc2626;">{d.ticket_id}</strong></td></tr>
      <tr><td style="padding:8px 16px;"><span style="color:#991b1b;font-size:13px;">Subject</span><br>
        <strong style="color:#1e293b;">{d.subject}</strong></td></tr>
      {"<tr><td style='padding:8px 16px;'><span style='color:#991b1b;font-size:13px;'>Description</span><br><span style='color:#1e293b;'>" + d.description[:300] + "</span></td></tr>" if d.description else ""}
      <tr><td style="padding:8px 16px;"><span style="color:#991b1b;font-size:13px;">User Email</span><br>
        <strong>{d.user_email}</strong></td></tr>
      <tr><td style="padding:8px 16px;"><span style="color:#991b1b;font-size:13px;">Department</span><br>
        <strong>{d.department.title()}</strong></td></tr>
      {"<tr><td style='padding:8px 16px;'><span style='color:#991b1b;font-size:13px;'>Deadline</span><br><strong>" + d.deadline + "</strong></td></tr>" if d.deadline else ""}
      {"<tr><td style='padding:8px 16px;'><span style='color:#991b1b;font-size:13px;'>AI Suggestion</span><br><span style='color:#1e293b;'>" + d.ai_suggestion[:500] + "</span></td></tr>" if d.ai_suggestion else ""}
    </table>

    <div style="background:#fef3c7;border-left:4px solid #f59e0b;border-radius:8px;padding:16px;margin-top:20px;">
      <p style="margin:0;font-size:14px;color:#92400e;">
        ⚡ <strong>Action Required:</strong> Please review and assign this ticket immediately.
      </p>
    </div>
    """
    return _base_html(body, "🚨 HIGH PRIORITY Ticket Alert")


# ── SMTP Send ───────────────────────────────────────────────────

def send_smtp_email(to: str, subject: str, html: str) -> bool:
    """Send an HTML email via Gmail SMTP."""
    if not SMTP_EMAIL or not SMTP_APP_PASSWORD:
        print(f"⚠️  SMTP not configured. Would send to: {to} | Subject: {subject}")
        return False

    try:
        msg = MIMEMultipart("alternative")
        msg["From"] = f"PRiorix Support <{SMTP_EMAIL}>"
        msg["To"] = to
        msg["Subject"] = subject
        msg.attach(MIMEText(html, "html"))

        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_EMAIL, SMTP_APP_PASSWORD)
            server.sendmail(SMTP_EMAIL, to, msg.as_string())

        print(f"✅ Email sent to {to} | {subject}")
        return True
    except Exception as e:
        print(f"❌ Email failed: {e}")
        return False


# ── API Routes ──────────────────────────────────────────────────

@app.get("/api/email/health")
async def health():
    return {
        "status": "ok",
        "smtp_configured": bool(SMTP_EMAIL and SMTP_APP_PASSWORD),
        "admin_email": ADMIN_EMAIL,
        "smtp_email": SMTP_EMAIL or "not set",
    }


@app.post("/api/email/test")
async def test_email():
    """Send a test email to the admin to verify SMTP configuration."""
    html = _base_html("""
    <p style="margin:0 0 16px;">Hi <strong>Admin</strong>,</p>
    <p style="margin:0 0 24px;">
      This is a <strong>test email</strong> from PRiorix. If you're seeing this, your email automation is working correctly! 🎉
    </p>
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:20px;">
      <tr><td style="padding:8px 16px;">
        <span style="color:#166534;font-size:14px;">✅ SMTP Connection: <strong>Working</strong></span>
      </td></tr>
      <tr><td style="padding:8px 16px;">
        <span style="color:#166534;font-size:14px;">✅ Sender: <strong>{}</strong></span>
      </td></tr>
      <tr><td style="padding:8px 16px;">
        <span style="color:#166534;font-size:14px;">✅ Admin Alert: <strong>{}</strong></span>
      </td></tr>
    </table>
    <div style="background:#ede9fe;border-left:4px solid #7c3aed;border-radius:8px;padding:16px;margin-top:20px;">
      <p style="margin:0;font-size:14px;color:#5b21b6;">
        📧 You will now receive automatic email notifications for:
      </p>
      <ul style="margin:8px 0 0;padding-left:20px;color:#5b21b6;font-size:14px;">
        <li>Ticket creation confirmations (sent to users)</li>
        <li>Status update notifications (sent to users)</li>
        <li>High-priority ticket alerts (sent to admin)</li>
      </ul>
    </div>
    """.format(SMTP_EMAIL, ADMIN_EMAIL), "✅ PRiorix Email Test")
    success = send_smtp_email(
        to=ADMIN_EMAIL,
        subject="✅ PRiorix Email Test — SMTP Working!",
        html=html,
    )
    return {"sent": success, "to": ADMIN_EMAIL}


@app.post("/api/email/ticket-created")
async def email_ticket_created(payload: TicketCreatedPayload):
    """Send ticket creation confirmation to the user."""
    html = ticket_created_html(payload)
    success = send_smtp_email(
        to=payload.to_email,
        subject=f"🎫 Ticket Created: {payload.subject} [#{payload.ticket_id[:8]}]",
        html=html,
    )
    return {"sent": success, "to": payload.to_email}


@app.post("/api/email/ticket-updated")
async def email_ticket_updated(payload: TicketUpdatedPayload):
    """Send status update notification to the user."""
    html = ticket_updated_html(payload)
    success = send_smtp_email(
        to=payload.to_email,
        subject=f"🔄 Ticket Update: {payload.subject} → {payload.new_status.replace('_',' ').title()} [#{payload.ticket_id[:8]}]",
        html=html,
    )
    return {"sent": success, "to": payload.to_email}


@app.post("/api/email/admin-alert")
async def email_admin_alert(payload: AdminAlertPayload):
    """Send high-priority alert to the admin."""
    html = admin_alert_html(payload)
    success = send_smtp_email(
        to=ADMIN_EMAIL,
        subject=f"🚨 HIGH PRIORITY: {payload.subject} [#{payload.ticket_id[:8]}]",
        html=html,
    )
    return {"sent": success, "to": ADMIN_EMAIL}


# ── Startup ─────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn

    print()
    print("=" * 60)
    print("  📧  PRiorix Email Automation Server")
    print("=" * 60)
    print(f"  Server:    http://localhost:{SERVER_PORT}")
    print(f"  SMTP:      {SMTP_SERVER}:{SMTP_PORT}")
    print(f"  Sender:    {SMTP_EMAIL or '⚠️  NOT SET'}")
    print(f"  Admin:     {ADMIN_EMAIL}")
    print(f"  Configured: {'✅ Yes' if (SMTP_EMAIL and SMTP_APP_PASSWORD) else '❌ No — set SMTP_EMAIL & SMTP_APP_PASSWORD in .env'}")
    print("=" * 60)
    print()

    uvicorn.run(app, host="0.0.0.0", port=SERVER_PORT)
